# AI Builder homepage integration

## Install

Extract the archive at the root of your existing Next.js repository and merge its `src/` folder with the repository's `src/` folder. Use the repository's existing package manifest, build configuration, environment variables and deployment workflow.

The homepage's photos, logos and fonts ship inside `src/components/public/home-assets/`. The Next.js build bundles them with the page.

## Homepage

- The reference design supplies the photo slideshow, partners, program milestones and impact numbers, program activities, curriculum, AI Hackathon, featured student projects, submission layout, FAQ and footer.
- The showcase displays the four projects from the reference, followed by the live published student and teacher listings and their detail links.
- The gallery uses the existing published records and year filters. The submission form sends entries through the application's existing review workflow.
- All LMS entry points go to `https://lms.awsinstem.id/login`. The footer contact is `marif.hidayatullah@prestasijunior.org`.

| File | Role |
| --- | --- |
| `src/app/page.tsx` | Homepage route, metadata and query parameters |
| `src/app/homepage.css` | Homepage typography and responsive layout |
| `src/components/public/AIBuilderHome.tsx` | Page layout and sections |
| `src/components/public/HomeInteractions.tsx` | Mobile navigation, hero slides, program counters, curriculum tabs, project carousel and footer mascot |
| `src/components/public/home-content.ts` | Program copy and photo selection |
| `src/components/public/home-assets/` | Optimized assets and font licenses |

The source package also includes the existing LMS login, admin and teacher routes, along with their application styles.
