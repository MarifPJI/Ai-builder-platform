'use client';

import { useFormState, useFormStatus } from 'react-dom';

import { Card, CardBody, CardHead } from '@/components/ui/Card';
import { Toast } from '@/components/ui/Toast';
import type { Karya } from '@/lib/domain/karya-service';

import { createKaryaAction, type KaryaFormState } from './actions';

const INIT: KaryaFormState = { status: 'idle' };

function SubmitBtn() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-white hover:bg-primary-hover disabled:opacity-50"
    >
      {pending ? 'Menerbitkan…' : 'Terbitkan Karya'}
    </button>
  );
}

export function KaryaPanels({ existing }: { existing: Karya[] }) {
  const [state, action] = useFormState(createKaryaAction, INIT);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHead title="Terbitkan Karya" />
        <CardBody>
          <form action={action} className="space-y-3">
            {state.status !== 'idle' && state.message ? (
              <Toast tone={state.status === 'ok' ? 'success' : 'error'} message={state.message} />
            ) : null}
            <div>
              <label className="mb-1 block text-sm font-medium text-ink">Tipe</label>
              <select
                name="type"
                className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
              >
                <option value="student">Proyek Siswa</option>
                <option value="teacher">Inovasi Guru</option>
              </select>
            </div>
            <Input name="title" label="Judul" />
            <Input name="category" label="Kategori" />
            <Input name="schoolName" label="Asal Sekolah" />
            <Input name="mentor" label="Kelas & Guru Pembimbing" required={false} />
            <Input name="demoUrl" label="Tautan Demo (opsional)" type="url" required={false} />
            <TextArea name="summary" label="Ringkasan Solusi AI" rows={3} />
            <TextArea name="detail" label="Detail (opsional)" rows={4} required={false} />
            <SubmitBtn />
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardHead title="Karya Terbit" />
        <CardBody className="p-0">
          {existing.length === 0 ? (
            <p className="px-6 py-8 text-center text-sm text-muted">Belum ada karya.</p>
          ) : (
            <ul className="divide-y divide-line">
              {existing.map((k) => (
                <li key={k.id} className="flex items-center justify-between px-6 py-3">
                  <div>
                    <p className="text-sm font-medium text-ink">{k.title}</p>
                    <p className="text-xs text-muted">
                      {k.type === 'student' ? 'Proyek Siswa' : 'Inovasi Guru'} · {k.schoolName}
                      {k.published ? '' : ' · (disembunyikan)'}
                    </p>
                  </div>
                  <a href={`/showcase/${k.id}`} target="_blank" rel="noreferrer" className="text-sm text-teal hover:underline">
                    Lihat →
                  </a>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </div>
  );
}

function Input({
  name,
  label,
  type = 'text',
  required = true,
}: {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-ink">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
      />
    </div>
  );
}

function TextArea({
  name,
  label,
  rows,
  required = true,
}: {
  name: string;
  label: string;
  rows: number;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-ink">{label}</label>
      <textarea
        name={name}
        rows={rows}
        required={required}
        className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
      />
    </div>
  );
}
