'use server';

import { revalidatePath } from 'next/cache';

import { requireSession } from '@/lib/auth/guard';
import { createKarya, setKaryaPublished } from '@/lib/domain/karya-service';

/**
 * Server Actions kelola Showcase Karya (admin). Semua diawali
 * requireSession({requireRole:'admin'}). Phase 1: tanpa unggah gambar.
 */
export interface KaryaFormState {
  status: 'idle' | 'ok' | 'error';
  message?: string;
}

export async function createKaryaAction(
  _prev: KaryaFormState,
  formData: FormData,
): Promise<KaryaFormState> {
  const claims = await requireSession({ requireRole: 'admin' });
  const type = String(formData.get('type') ?? 'student');
  const input = {
    type: type === 'teacher' ? ('teacher' as const) : ('student' as const),
    title: String(formData.get('title') ?? '').trim(),
    category: String(formData.get('category') ?? '').trim(),
    schoolName: String(formData.get('schoolName') ?? '').trim(),
    mentor: String(formData.get('mentor') ?? '').trim() || undefined,
    demoUrl: String(formData.get('demoUrl') ?? '').trim() || undefined,
    summary: String(formData.get('summary') ?? '').trim(),
    detail: String(formData.get('detail') ?? '').trim() || undefined,
  };

  if (!input.title || !input.category || !input.schoolName || !input.summary) {
    return { status: 'error', message: 'Judul, kategori, sekolah, dan ringkasan wajib diisi.' };
  }

  try {
    await createKarya(claims, input);
    revalidatePath('/admin/karya');
    revalidatePath('/');
    return { status: 'ok', message: 'Karya berhasil diterbitkan.' };
  } catch {
    return { status: 'error', message: 'Gagal menerbitkan karya. Silakan coba lagi.' };
  }
}

export async function toggleKaryaAction(id: string, published: boolean): Promise<void> {
  const claims = await requireSession({ requireRole: 'admin' });
  await setKaryaPublished(claims, id, published);
  revalidatePath('/admin/karya');
  revalidatePath('/');
}
