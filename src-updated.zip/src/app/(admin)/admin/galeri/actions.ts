'use server';

import { revalidatePath } from 'next/cache';

import { requireSession } from '@/lib/auth/guard';
import { createGalleryItem } from '@/lib/domain/gallery-service';

export interface GaleriFormState {
  status: 'idle' | 'ok' | 'error';
  message?: string;
}

export async function createGaleriAction(
  _prev: GaleriFormState,
  formData: FormData,
): Promise<GaleriFormState> {
  const claims = await requireSession({ requireRole: 'admin' });
  const year = Number(formData.get('year'));
  const title = String(formData.get('title') ?? '').trim();
  const caption = String(formData.get('caption') ?? '').trim() || undefined;

  if (!Number.isInteger(year) || year < 2024 || year > 2100) {
    return { status: 'error', message: 'Tahun tidak valid.' };
  }
  if (!title) {
    return { status: 'error', message: 'Judul wajib diisi.' };
  }

  try {
    await createGalleryItem(claims, { year, title, caption });
    revalidatePath('/admin/galeri');
    revalidatePath('/');
    return { status: 'ok', message: 'Item galeri berhasil diterbitkan.' };
  } catch {
    return { status: 'error', message: 'Gagal menerbitkan item galeri.' };
  }
}
