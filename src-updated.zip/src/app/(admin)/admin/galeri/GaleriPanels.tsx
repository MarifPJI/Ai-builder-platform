'use client';

import { useFormState, useFormStatus } from 'react-dom';

import { Card, CardBody, CardHead } from '@/components/ui/Card';
import { Toast } from '@/components/ui/Toast';
import type { GalleryItem } from '@/lib/domain/gallery-service';

import { createGaleriAction, type GaleriFormState } from './actions';

const INIT: GaleriFormState = { status: 'idle' };

function SubmitBtn() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-white hover:bg-primary-hover disabled:opacity-50"
    >
      {pending ? 'Menerbitkan…' : 'Terbitkan'}
    </button>
  );
}

export function GaleriPanels({ existing }: { existing: GalleryItem[] }) {
  const [state, action] = useFormState(createGaleriAction, INIT);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHead title="Terbitkan Item Galeri" />
        <CardBody>
          <form action={action} className="space-y-3">
            {state.status !== 'idle' && state.message ? (
              <Toast tone={state.status === 'ok' ? 'success' : 'error'} message={state.message} />
            ) : null}
            <div>
              <label className="mb-1 block text-sm font-medium text-ink">Tahun</label>
              <select
                name="year"
                className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
              >
                <option value="2024">2024</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink">Judul</label>
              <input
                name="title"
                required
                className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink">Keterangan (opsional)</label>
              <textarea
                name="caption"
                rows={3}
                className="w-full rounded-xl border border-line bg-white px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-teal"
              />
            </div>
            <p className="text-xs text-muted">Unggah foto tersedia pada tahap berikutnya (Phase 2).</p>
            <SubmitBtn />
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardHead title="Item Galeri" />
        <CardBody className="p-0">
          {existing.length === 0 ? (
            <p className="px-6 py-8 text-center text-sm text-muted">Belum ada item galeri.</p>
          ) : (
            <ul className="divide-y divide-line">
              {existing.map((g) => (
                <li key={g.id} className="px-6 py-3">
                  <p className="text-sm font-medium text-ink">{g.title}</p>
                  <p className="text-xs text-muted">
                    {g.year}
                    {g.caption ? ` · ${g.caption}` : ''}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
