/**
 * `teacherAccountService` — typed domain service untuk pengelolaan akun Guru
 * oleh Admin pada layar `A03` (lihat design.md > Components and Interfaces >
 * Typed domain services, serta diagram "Alur Aktivasi Akun Guru (A03)").
 *
 * STATUS: Berkas ini mengimplementasikan `createTeacher` (alur "sandi sementara"
 * / `AdminCreateUser` + FORCE_CHANGE_PASSWORD, task 10.2), `adminInviteTeacher`
 * (alur "undangan email" dengan rollback ketat, task 10.3), dan
 * `importTeachersCsv` (alur "impor CSV massal" dengan `ImportSummary`, task
 * 10.4), dan `activateTeachers` (aktivasi satuan/batch idempoten dengan
 * kegagalan sebagian, task 10.5). Kontrak `TeacherAccountService` kini lengkap.
 * Struktur modul — khususnya pabrik
 * `createTeacherAccountService(deps)` yang dapat di-inject — dirancang agar mudah
 * diperluas tanpa mengubah pemanggil.
 *
 * ── Alur `createTeacher` (R3.1, R3.2, R3.11, R5.2, R5.3) ─────────────────────
 *   1. Validasi BENTUK input (email, nama lengkap 1–150, school_id UUID).
 *   2. Verifikasi `school_id` TERDAFTAR via `schoolService.schoolExists` yang
 *      berjalan di bawah RLS (R5.2/R5.3). Tidak terdaftar → tolak dengan pesan
 *      berbahasa Indonesia.
 *   3. `AdminCreateUser` memakai email sebagai username, atribut `email` +
 *      `custom:school_id`, dengan kebijakan FORCE_CHANGE_PASSWORD (Cognito
 *      membuat sandi sementara karena `TemporaryPassword` tidak disetel).
 *      Lalu `AdminAddUserToGroup` menambahkan user ke grup `teacher` (R3.11).
 *   4. Insert ke tabel `profiles` (status `pending`, role `teacher`, school_id)
 *      via `withTenantTransaction(claims, ...)` di bawah RLS.
 *
 * ── Otorisasi ────────────────────────────────────────────────────────────────
 * HANYA Admin yang boleh memanggil operasi ini. Penegakan `requireSession({
 * requireRole: 'admin' })` dilakukan pada Server Action pemanggil (task 15.1);
 * service ini MENERIMA `claims` Admin yang sudah terverifikasi dan memakainya
 * sebagai konteks tenancy untuk `withTenantTransaction`. Service tidak mengulang
 * verifikasi JWT (itu tanggung jawab Session_Guard), namun mengandalkan RLS
 * sebagai lapis pertahanan kedua (deny-by-default).
 *
 * ── Keamanan ─────────────────────────────────────────────────────────────────
 * - `import 'server-only'` mencegah modul ini ikut ke bundel Client Component.
 * - Query basis data diparameterisasi (tanpa interpolasi string) untuk mencegah
 *   injeksi SQL.
 * - Tidak ada secret/kredensial yang di-hardcode; klien & konfigurasi Cognito
 *   dibaca dari environment sisi server melalui `./cognito`.
 *
 * _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.11, 5.2, 5.3_
 * (Property 5, Property 7, Property 8)
 */

import 'server-only';

import {
  AdminAddUserToGroupCommand,
  AdminCreateUserCommand,
  type AdminCreateUserCommandOutput,
  AdminDeleteUserCommand,
  AdminGetUserCommand,
  type AdminGetUserCommandOutput,
  AdminUpdateUserAttributesCommand,
  type AttributeType,
  type CognitoIdentityProviderClient,
} from '@aws-sdk/client-cognito-identity-provider';
import { z } from 'zod';

import {
  COGNITO_GROUPS,
  COGNITO_SCHOOL_ID_ATTRIBUTE,
  getCognitoClient,
  readCognitoConfig,
  type CognitoConfig,
} from '@/lib/auth/cognito';
import type { SessionClaims } from '@/lib/auth/types';
import { withTenantTransaction } from '@/lib/db/tenant-transaction';
import { emailSchema } from '@/lib/validation/auth';
import {
  MAX_CSV_ROWS,
  parseTeacherCsvRow,
  type RawTeacherCsvRow,
} from '@/lib/validation/csv';
import { schoolIdSchema } from '@/lib/validation/school';
// Task 10.1 (berjalan paralel) menyediakan schoolService di berkas ini.
// Import ini benar sesuai kontrak design.md (> Typed domain services):
//   schoolExists(claims, schoolId): Promise<boolean>
import { schoolExists } from './school-service';

/* ──────────────────────────────────────────────────────────────────────────
 * Kontrak masukan & keluaran
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Masukan pembuatan akun Guru (sesuai design.md: `CreateTeacherInput`).
 * - `email`    : email resmi Guru (jadi username Cognito & kolom `profiles.email`).
 * - `fullName` : nama lengkap Guru (1–150 karakter).
 * - `schoolId` : UUID sekolah yang WAJIB terdaftar pada tabel `schools`.
 */
export interface CreateTeacherInput {
  email: string;
  fullName: string;
  schoolId: string;
}

/**
 * Hasil pembuatan akun Guru.
 *
 * KEPUTUSAN DESAIN: meski kontrak `TeacherAccountService.createTeacher` pada
 * design.md bertipe `Promise<void>`, implementasi ini MENGEMBALIKAN pengenal
 * yang baru dibuat (`cognitoSub` dari hasil `AdminCreateUser` dan `profileId`
 * dari insert `profiles`). Alasan:
 * - Memudahkan pengujian berbasis properti (task 10.6/10.8) memverifikasi bahwa
 *   baris `profiles` benar-benar dibuat dengan `school_id` yang tepat (Property
 *   1 & 8) tanpa query tambahan.
 * - Memudahkan Server Action pemanggil (task 15.1) menautkan hasil ke UI.
 * Nilai balik ini bersifat aditif (superset dari `void`) sehingga tidak
 * melanggar kontrak bagi pemanggil yang hanya menunggu penyelesaian promise.
 */
export interface CreateTeacherResult {
  /** Subjek unik Cognito (`sub`) dari user yang baru dibuat. */
  cognitoSub: string;
  /** Primary key (`id`) baris `profiles` yang baru di-insert. */
  profileId: string;
}

/**
 * Error domain untuk kegagalan pembuatan akun Guru yang perlu ditampilkan ke
 * Admin dengan pesan berbahasa Indonesia (mis. input invalid, `school_id` tidak
 * terdaftar). Dipisahkan dari error infrastruktur agar Server Action dapat
 * memetakannya ke pesan UI yang ramah.
 */
export class CreateTeacherError extends Error {
  public constructor(message: string) {
    super(message);
    this.name = 'CreateTeacherError';
  }
}

/**
 * Item daftar akun Guru untuk layar admin `A03` (R2 — read side).
 *
 * Dipetakan dari baris `profiles` (snake_case → camelCase). Dipakai admin untuk
 * MELIHAT siapa yang masih `pending` dan mengaktifkannya per-baris (R3) tanpa
 * perlu menebak/menyalin UUID dari luar aplikasi.
 */
export interface TeacherListItem {
  id: string;
  cognitoSub: string;
  email: string;
  fullName: string;
  schoolId: string;
  activationStatus: string;
}

/**
 * Masukan adopsi/perbaikan akun Guru yang SUDAH ada di Cognito namun belum punya
 * profil di aplikasi (R2 — repair side). Bentuk sama dengan `CreateTeacherInput`.
 */
export interface AdoptCognitoTeacherInput {
  email: string;
  fullName: string;
  schoolId: string;
}

/** Hasil adopsi/perbaikan akun Guru dari Cognito. */
export interface AdoptCognitoTeacherResult {
  cognitoSub: string;
  profileId: string;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Impor CSV massal — kontrak masukan & keluaran (task 10.4; Property 7)
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Satu baris yang DITOLAK pada impor CSV, sesuai design.md (> Components and
 * Interfaces > Typed domain services: `interface RejectedRow`).
 *
 * - `line`  : nomor baris DATA berbasis-1 (baris pertama data = 1). Penomoran
 *             ini KONSISTEN baik untuk masukan array `RawTeacherCsvRow[]` maupun
 *             string CSV ber-header: untuk string CSV, baris header (bila ada)
 *             TIDAK dihitung sebagai data sehingga `line = 1` selalu menunjuk
 *             baris data pertama. Lihat {@link parseCsvFile}.
 * - `reason`: alasan penolakan berbahasa Indonesia (dari `parseTeacherCsvRow`
 *             untuk baris invalid, atau dari kegagalan pembuatan akun untuk
 *             baris yang valid bentuknya namun gagal dibuat).
 */
export interface RejectedRow {
  line: number;
  reason: string;
}

/**
 * Ringkasan hasil impor CSV, sesuai design.md (> Typed domain services:
 * `interface ImportSummary`).
 *
 * INVARIAN (Property 7): `created + rejected.length === total`. Setiap baris
 * data tepat berkontribusi pada SATU dari dua keluaran: berhasil dibuat
 * (`created`) atau ditolak (`rejected`) — tidak pernah keduanya, tidak pernah
 * tak-terhitung.
 */
export interface ImportSummary {
  /** Jumlah total baris DATA yang diproses (tidak termasuk header CSV). */
  total: number;
  /** Jumlah akun Guru yang berhasil dibuat (baris valid + pembuatan sukses). */
  created: number;
  /** Daftar baris yang ditolak beserta alasannya (Bahasa Indonesia). */
  rejected: RejectedRow[];
}

/**
 * Hasil aktivasi akun Guru secara batch (task 10.5; R3.9, R3.10; Property 5).
 *
 * INVARIAN (Property 5):
 * - `activated` dan `failed` bersifat DISJOINT (tidak ada `profileId` yang muncul
 *   di keduanya), dan gabungannya sama dengan himpunan input unik.
 * - Setiap `profileId` pada `activated` berstatus `active` setelah operasi.
 * - Setiap `profileId` pada `failed` TETAP `pending` (tidak berubah) — R3.10.
 * - Mengaktifkan ulang akun yang sudah `active` bersifat IDEMPOTEN: akun tsb
 *   masuk `activated` tanpa efek samping (tetap `active`).
 */
export interface ActivationResult {
  /** `profileId` yang berhasil diaktifkan (atau sudah aktif — idempoten). */
  activated: string[];
  /** `profileId` yang gagal diaktifkan; statusnya dipertahankan `pending`. */
  failed: string[];
}

/**
 * Bentuk masukan CSV untuk {@link TeacherAccountService.importTeachersCsv}.
 *
 * KEPUTUSAN DESAIN — bentuk input: `importTeachersCsv` menerima DUA bentuk
 * melalui satu tipe union yang bersih (design.md memberi kebebasan memilih):
 *
 *   1. `{ rows: RawTeacherCsvRow[] }` — baris mentah yang SUDAH diparse oleh
 *      pemanggil (mis. Server Action yang memakai pustaka parsing CSV/Excel di
 *      UI `A03`). Ini jalur yang disarankan karena parsing dilakukan sekali di
 *      tepi sistem; service domain fokus pada validasi + pembuatan akun.
 *
 *   2. `{ text: string }` — teks CSV mentah. Diparse oleh parser internal
 *      sederhana & aman ({@link parseCsvFile}) TANPA menambah dependency berat.
 *      Parser ini mendukung kutip ganda (`"`), escape `""`, dan koma di dalam
 *      field. Baris header opsional: bila header ada (mengandung token
 *      `email`), ia TIDAK dihitung sebagai baris data.
 *
 * Kedua bentuk menghasilkan penomoran `line` berbasis-1 atas baris DATA.
 */
export type CsvFile = { rows: RawTeacherCsvRow[] } | { text: string };

/**
 * Error yang dilempar ketika jumlah baris DATA CSV melebihi {@link MAX_CSV_ROWS}
 * (Requirement 3.5).
 *
 * KEPUTUSAN DESAIN — penegakan batas 1000 baris: bila jumlah baris data MELEBIHI
 * batas, SELURUH impor ditolak (fail-fast) dengan pesan berbahasa Indonesia,
 * BUKAN memproses sebagian lalu memotong sisanya. Alasan: batas adalah
 * precondition berkas; memotong diam-diam berisiko membuat Admin mengira semua
 * baris telah diproses. Penolakan menyeluruh ini terjadi SEBELUM baris mana pun
 * divalidasi/dibuat, sehingga tidak ada akun yang terlanjur dibuat.
 */
export class CsvRowLimitError extends Error {
  public constructor(
    message: string,
    public readonly rowCount: number,
    public readonly maxRows: number,
  ) {
    super(message);
    this.name = 'CsvRowLimitError';
  }
}

/* ──────────────────────────────────────────────────────────────────────────
 * Validasi bentuk masukan
 * ────────────────────────────────────────────────────────────────────────── */

/** Batas panjang nama lengkap (sejalan CHECK `profiles.full_name` 1–150). */
export const FULL_NAME_MIN_LENGTH = 1 as const;
export const FULL_NAME_MAX_LENGTH = 150 as const;

/**
 * Masa berlaku maksimum undangan email akun Guru, dalam hari (R3.3).
 *
 * PENEGAKAN TTL — PENTING: TTL 7 hari ini ditegakkan di KONFIGURASI User Pool
 * (lapisan infrastruktur), BUKAN per-permintaan di kode aplikasi. Amazon Cognito
 * mengatur masa berlaku kredensial sementara/undangan melalui
 * `AdminCreateUserConfig.UnusedAccountValidityDays` (kedaluwarsa ≤ 7 hari) — atau
 * kebijakan password User Pool untuk versi API yang lebih baru. `AdminCreateUser`
 * (tanpa `MessageAction: 'RESEND'/'SUPPRESS'`) memakai nilai default User Pool
 * tersebut saat mengirim undangan. Konstanta ini adalah referensi kanonis nilai
 * yang WAJIB dikonfigurasi di infra (`UnusedAccountValidityDays <= 7`) dan dipakai
 * kode aplikasi sebagai dokumentasi + titik pemeriksaan ekspektasi; service ini
 * tidak dapat (dan tidak seharusnya) mengubah kebijakan User Pool per permintaan.
 */
export const INVITATION_TTL_DAYS = 7 as const;

/**
 * Skema nama lengkap: dipangkas, panjang 1–150 karakter. Pesan berbahasa
 * Indonesia. Konsisten dengan CHECK constraint `profiles.full_name`.
 */
const fullNameSchema = z
  .string({
    required_error: 'Nama lengkap wajib diisi.',
    invalid_type_error: 'Nama lengkap tidak valid.',
  })
  .trim()
  .min(FULL_NAME_MIN_LENGTH, { message: 'Nama lengkap wajib diisi.' })
  .max(FULL_NAME_MAX_LENGTH, {
    message: `Nama lengkap maksimum ${FULL_NAME_MAX_LENGTH} karakter.`,
  });

/**
 * Skema `CreateTeacherInput` (bentuk saja; validasi referensial `school_id`
 * dilakukan terpisah via `schoolService.schoolExists`).
 */
const createTeacherInputSchema = z.object({
  email: emailSchema,
  fullName: fullNameSchema,
  schoolId: schoolIdSchema,
});

/** Masukan yang sudah tervalidasi bentuknya. */
type ValidatedCreateTeacherInput = z.infer<typeof createTeacherInputSchema>;

/**
 * Memvalidasi bentuk `CreateTeacherInput`. Melempar `CreateTeacherError` dengan
 * pesan gabungan berbahasa Indonesia bila ada kolom yang tidak valid.
 */
function validateInput(input: CreateTeacherInput): ValidatedCreateTeacherInput {
  const result = createTeacherInputSchema.safeParse(input);
  if (!result.success) {
    const reasons = result.error.issues.map((issue) => issue.message);
    const reason =
      reasons.length > 0 ? reasons.join(' ') : 'Masukan akun Guru tidak valid.';
    throw new CreateTeacherError(reason);
  }
  return result.data;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Dependensi yang dapat di-inject (agar PBT task 10.6/10.8 hemat & deterministik)
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Pemeriksa keberadaan sekolah (validasi referensial `school_id`). Default
 * memakai `schoolService.schoolExists` (task 10.1) yang berjalan di bawah RLS.
 * Dibuat injectable agar pengujian dapat menyediakan stub tanpa basis data.
 */
export type SchoolExistsFn = (
  claims: SessionClaims,
  schoolId: string,
) => Promise<boolean>;

/**
 * Pembungkus transaksi tenancy. Default memakai `withTenantTransaction` nyata;
 * dapat di-inject untuk pengujian.
 */
export type WithTenantTransactionFn = typeof withTenantTransaction;

/** Dependensi `teacherAccountService`; seluruhnya opsional dengan default produksi. */
export interface TeacherAccountServiceDeps {
  readonly client?: CognitoIdentityProviderClient;
  readonly config?: CognitoConfig;
  readonly schoolExists?: SchoolExistsFn;
  readonly withTenantTransaction?: WithTenantTransactionFn;
}

/** Kontrak publik bagian yang diimplementasikan pada task 10.2. */
export interface TeacherAccountService {
  /**
   * Membuat akun Guru via alur sandi sementara (AdminCreateUser +
   * FORCE_CHANGE_PASSWORD) lalu insert profil berstatus `pending`.
   *
   * @param claims Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @param input  Data Guru yang akan dibuat.
   * @returns `cognitoSub` dan `profileId` yang baru dibuat.
   * @throws {CreateTeacherError} bila input invalid atau `school_id` tak terdaftar.
   */
  createTeacher(
    claims: SessionClaims,
    input: CreateTeacherInput,
  ): Promise<CreateTeacherResult>;

  /**
   * Membuat akun Guru via alur UNDANGAN EMAIL (R3.3, R3.4). Cognito mengirim
   * email undangan berisi kredensial sementara (status FORCE_CHANGE_PASSWORD);
   * masa berlaku undangan maksimum {@link INVITATION_TTL_DAYS} hari ditegakkan di
   * konfigurasi User Pool. Bila pengiriman undangan GAGAL, pembuatan akun terkait
   * di-rollback secara ketat sehingga jumlah profil persisten TIDAK bertambah
   * (Property 5).
   *
   * @param claims Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @param input  Data Guru yang akan diundang.
   * @returns `cognitoSub` dan `profileId` yang baru dibuat.
   * @throws {CreateTeacherError} bila input invalid, `school_id` tak terdaftar,
   *   atau pengiriman undangan gagal (setelah kompensasi/rollback dilakukan).
   */
  adminInviteTeacher(
    claims: SessionClaims,
    input: CreateTeacherInput,
  ): Promise<CreateTeacherResult>;

  /**
   * Mengimpor akun Guru secara massal dari berkas CSV (R3.5–R3.8; Property 7).
   *
   * Perilaku:
   * - Menerima maksimum {@link MAX_CSV_ROWS} (1000) baris DATA. Bila melebihi,
   *   SELURUH impor ditolak dengan melempar {@link CsvRowLimitError} (R3.5) —
   *   tidak ada akun yang dibuat.
   * - Memvalidasi tiap baris memakai `parseTeacherCsvRow` (R3.6). Baris invalid
   *   DILEWATI dan dicatat alasannya pada `rejected`, lalu impor LANJUT ke baris
   *   berikutnya (R3.7).
   * - Baris valid dibuat memakai alur yang sama dengan {@link createTeacher}
   *   (verifikasi `school_id` terdaftar → `AdminCreateUser` + grup teacher +
   *   insert `profiles` pending). Bila pembuatan SATU baris valid gagal di tengah
   *   (mis. `school_id` tidak terdaftar atau galat Cognito), baris itu
   *   diperlakukan sebagai `rejected` dengan alasan — TANPA menggagalkan seluruh
   *   impor. Ini menjaga invarian Property 7.
   * - Mengembalikan {@link ImportSummary} dengan invarian
   *   `created + rejected.length === total` (R3.8; Property 7).
   *
   * @param claims Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @param csv    Berkas CSV: `{ rows }` (sudah diparse) atau `{ text }` (mentah).
   * @returns Ringkasan impor (`total`, `created`, `rejected`).
   * @throws {CsvRowLimitError} bila jumlah baris data melebihi {@link MAX_CSV_ROWS}.
   */
  importTeachersCsv(
    claims: SessionClaims,
    csv: CsvFile,
  ): Promise<ImportSummary>;

  /**
   * Mengaktifkan akun Guru secara satuan atau batch (R3.9, R3.10; Property 5).
   *
   * Perilaku:
   * - Untuk setiap `profileId`, mengubah `activation_status` menjadi `active`
   *   pada tabel `profiles` di bawah RLS (R3.9).
   * - Aktivasi bersifat IDEMPOTEN: akun yang sudah `active` tetap `active` dan
   *   dilaporkan pada `activated` tanpa efek samping.
   * - Bila SEBAGIAN akun gagal diaktifkan, akun yang gagal TETAP `pending` dan
   *   dilaporkan pada `failed`; akun lain tetap diproses (R3.10). Himpunan
   *   `activated` dan `failed` disjoint dan gabungannya = input unik (Property 5).
   * - `profileId` yang tidak ditemukan/tidak terlihat di bawah RLS diperlakukan
   *   sebagai `failed` (deny-by-default) tanpa menggagalkan batch.
   *
   * @param claims     Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @param profileIds Daftar `profiles.id` (UUID) yang akan diaktifkan.
   * @returns {@link ActivationResult} berisi `activated` dan `failed`.
   */
  activateTeachers(
    claims: SessionClaims,
    profileIds: string[],
  ): Promise<ActivationResult>;

  /**
   * Mengembalikan daftar seluruh akun Guru beserta status aktivasinya (R2 —
   * read side). Dijalankan di bawah RLS via `withTenantTransaction`; kebijakan
   * `profiles_admin_read` (migrasi 0002) mengizinkan admin membaca lintas
   * sekolah. Diurutkan `pending` lebih dulu lalu nama lengkap agar admin mudah
   * menemukan akun yang perlu diaktifkan.
   *
   * @param claims Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @returns Daftar {@link TeacherListItem}.
   */
  listTeachers(claims: SessionClaims): Promise<TeacherListItem[]>;

  /**
   * Mengadopsi/memperbaiki akun Guru yang SUDAH ada di Cognito tetapi belum
   * memiliki baris `profiles` di aplikasi (R2 — repair side). Mengodekan
   * perbaikan manual (SQL upsert + set `custom:school_id` + grup teacher)
   * menjadi aksi admin yang aman & idempoten.
   *
   * Langkah:
   *   1. Validasi bentuk input (email, nama lengkap 1–150, school_id UUID).
   *   2. Verifikasi `school_id` TERDAFTAR via `schoolExists` (di bawah RLS).
   *   3. `AdminGetUser` untuk mengambil `sub`; tidak ditemukan → tolak (ID).
   *   4. Set `custom:school_id` HANYA bila hilang/berbeda.
   *   5. Pastikan keanggotaan grup `teacher` (idempoten).
   *   6. Upsert baris `profiles` keyed pada `cognito_sub` dengan status
   *      `pending` — TIDAK PERNAH mengaktifkan otomatis (AGENTS.md §1: aktivasi
   *      hanya oleh Admin via alur aktivasi).
   *
   * @param claims Klaim Admin terverifikasi (dari Session_Guard di pemanggil).
   * @param input  Data Guru yang akan diadopsi/diperbaiki.
   * @returns `cognitoSub` dan `profileId` (baru atau yang sudah ada).
   * @throws {CreateTeacherError} bila input invalid, `school_id` tak terdaftar,
   *   atau pengguna tidak ditemukan di penyedia identitas.
   */
  adoptCognitoTeacher(
    claims: SessionClaims,
    input: AdoptCognitoTeacherInput,
  ): Promise<AdoptCognitoTeacherResult>;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Util internal
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Mengambil `cognitoSub` (klaim `sub`) dari hasil `AdminCreateUser`.
 *
 * Cognito mengembalikan atribut user pada `User.Attributes`. `sub` adalah
 * pengenal stabil yang dipakai sebagai `profiles.cognito_sub` (bukan
 * `Username`, karena username bisa sama dengan email dan dapat berubah pada
 * konfigurasi tertentu). Mengembalikan `undefined` bila tidak ditemukan.
 */
function extractCognitoSub(
  output: AdminCreateUserCommandOutput,
): string | undefined {
  const attributes = output.User?.Attributes ?? [];
  const subAttr = attributes.find((attr) => attr.Name === 'sub');
  return subAttr?.Value ?? undefined;
}

/**
 * Mengambil nilai atribut tertentu dari daftar `AttributeType` (bentuk yang
 * dikembalikan `AdminGetUser` pada `UserAttributes`). Dipakai oleh
 * {@link createTeacherAccountService}.adoptCognitoTeacher untuk membaca `sub`
 * dan `custom:school_id`. Tidak mengubah {@link extractCognitoSub} (yang terikat
 * ke keluaran `AdminCreateUser`). Mengembalikan `undefined` bila tidak ada.
 */
function findAttributeValue(
  attributes: AttributeType[] | undefined,
  name: string,
): string | undefined {
  return (attributes ?? []).find((attr) => attr.Name === name)?.Value ?? undefined;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Parser CSV internal (sederhana & aman, tanpa dependency berat)
 * ────────────────────────────────────────────────────────────────────────── */

/** Kolom yang dikenali pada header CSV, dipetakan ke properti RawTeacherCsvRow. */
const CSV_HEADER_ALIASES: Readonly<Record<string, keyof RawTeacherCsvRow>> = {
  email: 'email',
  'email resmi': 'email',
  fullname: 'fullName',
  'full name': 'fullName',
  'nama lengkap': 'fullName',
  nama: 'fullName',
  schoolid: 'schoolId',
  'school id': 'schoolId',
  'school_id': 'schoolId',
  'id sekolah': 'schoolId',
} as const;

/** Urutan kolom default bila CSV TIDAK memiliki baris header yang dikenali. */
const CSV_DEFAULT_COLUMNS: readonly (keyof RawTeacherCsvRow)[] = [
  'email',
  'fullName',
  'schoolId',
] as const;

/**
 * Memisah satu baris CSV menjadi field-field, menghormati kutip ganda (`"`),
 * escape `""` di dalam kutip, dan koma pemisah. Parser bersifat lokal per baris
 * (tidak mendukung newline di dalam field berkutip) — cukup & aman untuk impor
 * daftar Guru. Tidak menambah dependency eksternal.
 */
function splitCsvLine(line: string): string[] {
  const fields: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (inQuotes) {
      if (char === '"') {
        if (line[i + 1] === '"') {
          // Escape kutip ganda ("") → satu kutip literal.
          current += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
    } else if (char === '"') {
      inQuotes = true;
    } else if (char === ',') {
      fields.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  fields.push(current);
  return fields;
}

/**
 * Menentukan apakah daftar sel merupakan baris HEADER (bukan data). Heuristik:
 * baris dianggap header bila SETIAP selnya dikenali sebagai alias kolom
 * (lihat {@link CSV_HEADER_ALIASES}). Ini mencegah baris data yang kebetulan
 * mengandung kata "email" (mis. nilai email) salah dikira header.
 */
function looksLikeHeader(cells: string[]): boolean {
  if (cells.length === 0) {
    return false;
  }
  return cells.every((cell) =>
    Object.prototype.hasOwnProperty.call(
      CSV_HEADER_ALIASES,
      cell.trim().toLowerCase(),
    ),
  );
}

/**
 * Mem-parse teks CSV mentah menjadi daftar {@link RawTeacherCsvRow}.
 *
 * Aturan:
 * - Memisah baris pada `\n` (menoleransi `\r\n`).
 * - Baris yang SELURUHNYA kosong (tanpa konten) DILEWATI dan TIDAK dihitung
 *   sebagai baris data (tidak menambah `total`), agar newline akhir berkas atau
 *   baris kosong insidental tidak menghasilkan baris tolakan yang membingungkan.
 * - Bila baris pertama (non-kosong) adalah header yang dikenali, pemetaan kolom
 *   mengikuti header tersebut dan baris header TIDAK dihitung sebagai data.
 * - Bila tidak ada header dikenali, kolom mengikuti urutan default
 *   `email, fullName, schoolId`.
 *
 * Mengembalikan baris mentah (belum divalidasi); validasi bentuk tetap dilakukan
 * `parseTeacherCsvRow` di pemanggil sehingga penomoran `line` konsisten.
 */
function parseCsvFile(text: string): RawTeacherCsvRow[] {
  const rawLines = text.split('\n').map((line) => line.replace(/\r$/, ''));

  // Pasangan (sel) untuk setiap baris non-kosong.
  const nonEmpty: string[][] = [];
  for (const line of rawLines) {
    if (line.trim() === '') {
      continue; // Lewati baris kosong; tidak dihitung sebagai data.
    }
    nonEmpty.push(splitCsvLine(line));
  }

  if (nonEmpty.length === 0) {
    return [];
  }

  let columns: (keyof RawTeacherCsvRow)[];
  let dataRows: string[][];

  if (looksLikeHeader(nonEmpty[0]!)) {
    columns = nonEmpty[0]!.map(
      (cell) => CSV_HEADER_ALIASES[cell.trim().toLowerCase()]!,
    );
    dataRows = nonEmpty.slice(1);
  } else {
    columns = [...CSV_DEFAULT_COLUMNS];
    dataRows = nonEmpty;
  }

  return dataRows.map((cells) => {
    const row: RawTeacherCsvRow = {};
    columns.forEach((col, index) => {
      const value = cells[index];
      if (value !== undefined) {
        row[col] = value.trim();
      }
    });
    return row;
  });
}

/**
 * Menormalkan masukan {@link CsvFile} menjadi daftar baris mentah
 * {@link RawTeacherCsvRow}, baik dari `{ rows }` maupun `{ text }`.
 */
function normalizeCsvInput(csv: CsvFile): RawTeacherCsvRow[] {
  if ('rows' in csv) {
    return csv.rows;
  }
  return parseCsvFile(csv.text);
}

/* ──────────────────────────────────────────────────────────────────────────
 * Pabrik service
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Membuat instance `teacherAccountService`. Tanpa argumen, memakai klien &
 * konfigurasi Cognito produksi, `schoolService.schoolExists` nyata, dan
 * `withTenantTransaction` nyata. Pengujian menyuntikkan dependensi tiruan.
 */
export function createTeacherAccountService(
  deps: TeacherAccountServiceDeps = {},
): TeacherAccountService {
  const config = deps.config ?? readCognitoConfig();
  const client = deps.client ?? getCognitoClient();
  const schoolExistsFn = deps.schoolExists ?? schoolExists;
  const runInTenantTransaction =
    deps.withTenantTransaction ?? withTenantTransaction;

  /**
   * Inti pembuatan akun Guru via alur SANDI SEMENTARA untuk masukan yang SUDAH
   * tervalidasi bentuknya. Dipakai bersama oleh {@link createTeacher} (satu
   * akun) dan {@link importTeachersCsv} (massal), sehingga logika pembuatan
   * (verifikasi `school_id` terdaftar → `AdminCreateUser` + grup teacher →
   * insert `profiles` pending) TIDAK terduplikasi.
   *
   * Melempar {@link CreateTeacherError} bila `school_id` tidak terdaftar atau
   * pembuatan gagal di tengah; pemanggil memutuskan cara menangani (createTeacher
   * meneruskan error; importTeachersCsv memperlakukannya sebagai baris tolakan).
   */
  async function createValidatedTeacher(
    claims: SessionClaims,
    valid: ValidatedCreateTeacherInput,
  ): Promise<CreateTeacherResult> {
    // 1. Verifikasi school_id TERDAFTAR (R5.2/R5.3). Berjalan di bawah RLS via
    //    schoolService.schoolExists. Tidak terdaftar → tolak (pesan ID).
    const exists = await schoolExistsFn(claims, valid.schoolId);
    if (!exists) {
      throw new CreateTeacherError(
        'ID sekolah tidak terdaftar. Akun Guru tidak dapat dibuat.',
      );
    }

    // 2. AdminCreateUser: email sebagai username, atribut email + custom:school_id,
    //    kebijakan FORCE_CHANGE_PASSWORD. Tanpa `TemporaryPassword`, Cognito
    //    membuat sandi sementara sendiri (R3.2). Lalu tambahkan ke grup teacher.
    let createOutput: AdminCreateUserCommandOutput;
    try {
      createOutput = await client.send(
        new AdminCreateUserCommand({
          UserPoolId: config.userPoolId,
          Username: valid.email,
          // Tidak menyetel TemporaryPassword → Cognito membangkitkan sandi
          // sementara dan memaksa FORCE_CHANGE_PASSWORD pada login pertama.
          UserAttributes: [
            { Name: 'email', Value: valid.email },
            { Name: 'email_verified', Value: 'true' },
            { Name: COGNITO_SCHOOL_ID_ATTRIBUTE, Value: valid.schoolId },
          ],
          // Catatan: nilai default Cognito untuk AdminCreateUser mengirim
          // undangan + menandai status FORCE_CHANGE_PASSWORD.
        }),
      );
    } catch {
      // Bungkus error Cognito sebagai error domain berbahasa Indonesia agar
      // pemanggil dapat menampilkannya dengan aman (tanpa membocorkan detail
      // penyedia identitas ke pengguna akhir).
      throw new CreateTeacherError(
        'Gagal membuat akun Guru di penyedia identitas. Silakan coba lagi.',
      );
    }

    const cognitoSub = extractCognitoSub(createOutput);
    if (!cognitoSub) {
      // Tanpa `sub`, profil tidak dapat ditautkan secara konsisten ke Cognito.
      throw new CreateTeacherError(
        'Pembuatan akun Guru tidak mengembalikan identitas yang valid.',
      );
    }

    // Tambahkan user ke grup `teacher` (R3.11). Peran ditentukan oleh grup ini.
    await client.send(
      new AdminAddUserToGroupCommand({
        UserPoolId: config.userPoolId,
        Username: valid.email,
        GroupName: COGNITO_GROUPS.teacher,
      }),
    );

    // 3. Insert ke `profiles` (status pending, role teacher, school_id) di bawah
    //    RLS. Query diparameterisasi untuk mencegah injeksi.
    const profileId = await runInTenantTransaction(claims, async (tx) => {
      const result = await tx.query<{ id: string }>(
        `INSERT INTO profiles
           (cognito_sub, email, full_name, role, school_id, activation_status)
         VALUES ($1, $2, $3, 'teacher', $4, 'pending')
         RETURNING id`,
        [cognitoSub, valid.email, valid.fullName, valid.schoolId],
      );
      const row = result.rows[0];
      if (!row) {
        // Insert tidak mengembalikan baris → anggap gagal; transaksi di-rollback
        // oleh withTenantTransaction saat error dilempar (deny-by-default).
        throw new CreateTeacherError('Gagal menyimpan profil Guru.');
      }
      return row.id;
    });

    return { cognitoSub, profileId };
  }

  async function createTeacher(
    claims: SessionClaims,
    input: CreateTeacherInput,
  ): Promise<CreateTeacherResult> {
    // Validasi bentuk input (email, nama lengkap 1–150, school_id UUID), lalu
    // delegasikan ke inti pembuatan bersama.
    const valid = validateInput(input);
    return createValidatedTeacher(claims, valid);
  }

  /**
   * Impor CSV massal dengan `ImportSummary` (R3.5–R3.8; Property 7).
   *
   * ── Alur (design.md > Alur Aktivasi Akun Guru (A03) > "Alur 3 — Impor CSV") ──
   *   1. Normalkan masukan menjadi daftar baris mentah (`{ rows }` atau `{ text }`).
   *   2. Tegakkan batas {@link MAX_CSV_ROWS} (R3.5): jika jumlah baris data
   *      MELEBIHI batas → lempar {@link CsvRowLimitError} (seluruh impor ditolak
   *      SEBELUM baris mana pun diproses; tidak ada akun dibuat).
   *   3. Untuk tiap baris (penomoran `line` berbasis-1 atas baris data):
   *      a. `parseTeacherCsvRow` (R3.6). Invalid → push ke `rejected` {line,
   *         reason} dan LANJUT (R3.7).
   *      b. Valid → `createValidatedTeacher` (alur createTeacher). Jika pembuatan
   *         gagal di tengah (school_id tak terdaftar / galat Cognito/DB) → baris
   *         itu diperlakukan sebagai `rejected` dengan alasan, TANPA menggagalkan
   *         seluruh impor.
   *   4. Kembalikan {@link ImportSummary}; invarian `created + rejected.length
   *      === total` dijamin karena tiap baris menambah TEPAT satu dari `created`
   *      atau `rejected` (Property 7).
   */
  async function importTeachersCsv(
    claims: SessionClaims,
    csv: CsvFile,
  ): Promise<ImportSummary> {
    // 1. Normalkan masukan ke daftar baris mentah.
    const rows = normalizeCsvInput(csv);

    // 2. Tegakkan batas 1000 baris (R3.5) SEBELUM memproses baris mana pun.
    if (rows.length > MAX_CSV_ROWS) {
      throw new CsvRowLimitError(
        `Jumlah baris CSV (${rows.length}) melebihi batas maksimum ` +
          `${MAX_CSV_ROWS} baris. Impor dibatalkan; tidak ada akun yang dibuat.`,
        rows.length,
        MAX_CSV_ROWS,
      );
    }

    const total = rows.length;
    const rejected: RejectedRow[] = [];
    let created = 0;

    // 3. Proses tiap baris; penomoran `line` berbasis-1 atas baris data.
    for (let index = 0; index < rows.length; index += 1) {
      const line = index + 1;
      const parsed = parseTeacherCsvRow(rows[index]!);

      if (!parsed.valid) {
        // Baris invalid → catat alasan dan lanjut (R3.7).
        rejected.push({ line, reason: parsed.reason });
        continue;
      }

      // Baris valid → coba buat akun memakai alur createTeacher bersama.
      try {
        await createValidatedTeacher(claims, parsed.value);
        created += 1;
      } catch (error) {
        // Kegagalan pembuatan SATU baris valid tidak boleh menggagalkan seluruh
        // impor: perlakukan sebagai baris tolakan dengan alasan (menjaga
        // invarian Property 7: created + rejected.length === total).
        const reason =
          error instanceof CreateTeacherError
            ? error.message
            : 'Gagal membuat akun Guru untuk baris ini. Silakan coba lagi.';
        rejected.push({ line, reason });
      }
    }

    return { total, created, rejected };
  }

  /**
   * Alur UNDANGAN EMAIL dengan ROLLBACK KETAT (R3.3, R3.4; Property 5).
   *
   * ── Alur (design.md > Alur Aktivasi Akun Guru (A03) > "Alur 2 — Undangan email") ─
   *   1. Validasi BENTUK input (email, nama lengkap 1–150, school_id UUID).
   *   2. Verifikasi `school_id` TERDAFTAR via `schoolExists` (di bawah RLS,
   *      R5.2/R5.3). Tidak terdaftar → tolak (pesan berbahasa Indonesia).
   *   3. `AdminCreateUser` dengan `DesiredDeliveryMediums=['EMAIL']` sehingga
   *      Cognito MENGIRIM undangan email berisi kredensial sementara; status
   *      FORCE_CHANGE_PASSWORD. Masa berlaku undangan ≤ 7 hari ditegakkan oleh
   *      konfigurasi User Pool (lihat {@link INVITATION_TTL_DAYS}). Pada alur ini
   *      pengiriman undangan terjadi SEBAGAI BAGIAN dari AdminCreateUser; bila
   *      email gagal terkirim, AdminCreateUser melempar error.
   *   4. Tambahkan user ke grup `teacher` (R3.11).
   *   5. Insert `profiles` (status `pending`) via `withTenantTransaction`.
   *
   * ── STRATEGI KOMPENSASI / ROLLBACK (R3.4; Property 5) ────────────────────────
   * Invarian Property 5: bila langkah undangan GAGAL, jumlah profil persisten
   * TIDAK bertambah. Strategi berlapis untuk menjamin invarian ini:
   *
   *   (a) URUTAN: insert `profiles` dilakukan SETELAH undangan dipastikan terkirim
   *       (AdminCreateUser dengan DesiredDeliveryMediums EMAIL sukses). Jadi bila
   *       pengiriman undangan gagal, tidak pernah ada baris `profiles` yang
   *       ter-insert — jumlah profil otomatis tetap (0 pertambahan).
   *
   *   (b) KOMPENSASI user Cognito: bila AdminCreateUser berhasil membuat user
   *       TETAPI langkah lanjutan gagal (penambahan grup, atau insert `profiles`),
   *       user Cognito yang telanjur dibuat DIBERSIHKAN via `AdminDeleteUser`
   *       (best-effort). Ini mencegah user "menggantung" tanpa profil dan menjaga
   *       konsistensi Cognito↔DB. `withTenantTransaction` sendiri me-rollback
   *       transaksi DB saat `fn` melempar, sehingga baris `profiles` tidak persisten
   *       (deny-by-default). Setelah kompensasi, error domain berbahasa Indonesia
   *       dilempar ke pemanggil.
   *
   * Kegagalan kompensasi Cognito (mis. AdminDeleteUser ikut gagal) tidak boleh
   * menutupi penyebab utama: kita tetap melempar error undangan berbahasa
   * Indonesia. Invarian jumlah profil (Property 5) tetap terjaga karena insert
   * profiles hanya terjadi pada jalur sukses penuh.
   */
  async function adminInviteTeacher(
    claims: SessionClaims,
    input: CreateTeacherInput,
  ): Promise<CreateTeacherResult> {
    // 1. Validasi bentuk input.
    const valid = validateInput(input);

    // 2. Verifikasi school_id TERDAFTAR (R5.2/R5.3) di bawah RLS.
    const exists = await schoolExistsFn(claims, valid.schoolId);
    if (!exists) {
      throw new CreateTeacherError(
        'ID sekolah tidak terdaftar. Undangan akun Guru tidak dapat dikirim.',
      );
    }

    // 3. AdminCreateUser dengan DesiredDeliveryMediums=['EMAIL']: Cognito mengirim
    //    undangan email berisi kredensial sementara (FORCE_CHANGE_PASSWORD). Tanpa
    //    `TemporaryPassword`, Cognito membangkitkan sandi sementara sendiri. TTL
    //    undangan (≤ 7 hari) ditegakkan di konfigurasi User Pool (INVITATION_TTL_DAYS).
    //    Jika pengiriman undangan gagal, panggilan ini melempar → tidak ada profil
    //    yang ter-insert (lihat strategi (a)).
    let createOutput: AdminCreateUserCommandOutput;
    try {
      createOutput = await client.send(
        new AdminCreateUserCommand({
          UserPoolId: config.userPoolId,
          Username: valid.email,
          DesiredDeliveryMediums: ['EMAIL'],
          UserAttributes: [
            { Name: 'email', Value: valid.email },
            { Name: 'email_verified', Value: 'true' },
            { Name: COGNITO_SCHOOL_ID_ATTRIBUTE, Value: valid.schoolId },
          ],
        }),
      );
    } catch {
      // Pengiriman undangan gagal pada tahap pembuatan user: BELUM ada user
      // persisten yang perlu dibersihkan dan BELUM ada profil ter-insert
      // (strategi (a)). Lempar error domain berbahasa Indonesia (R3.4).
      throw new CreateTeacherError(
        'Gagal mengirim undangan email akun Guru. Pembuatan akun dibatalkan. ' +
          'Silakan coba lagi.',
      );
    }

    const cognitoSub = extractCognitoSub(createOutput);
    if (!cognitoSub) {
      // User mungkin telanjur dibuat namun tanpa `sub` yang valid: kompensasi
      // (hapus user Cognito) agar tidak menggantung, lalu tolak.
      await compensateDeleteCognitoUser(valid.email);
      throw new CreateTeacherError(
        'Undangan akun Guru tidak mengembalikan identitas yang valid. ' +
          'Pembuatan akun dibatalkan.',
      );
    }

    // Mulai titik ini user Cognito SUDAH dibuat & undangan SUDAH terkirim. Setiap
    // kegagalan lanjutan harus memicu KOMPENSASI (hapus user Cognito) agar tidak
    // ada user menggantung dan jumlah profil tidak bertambah (Property 5).
    try {
      // 4. Tambahkan user ke grup `teacher` (R3.11).
      await client.send(
        new AdminAddUserToGroupCommand({
          UserPoolId: config.userPoolId,
          Username: valid.email,
          GroupName: COGNITO_GROUPS.teacher,
        }),
      );

      // 5. Insert `profiles` (status pending) di bawah RLS. Query diparameterisasi.
      //    withTenantTransaction me-rollback transaksi bila callback melempar.
      const profileId = await runInTenantTransaction(claims, async (tx) => {
        const result = await tx.query<{ id: string }>(
          `INSERT INTO profiles
             (cognito_sub, email, full_name, role, school_id, activation_status)
           VALUES ($1, $2, $3, 'teacher', $4, 'pending')
           RETURNING id`,
          [cognitoSub, valid.email, valid.fullName, valid.schoolId],
        );
        const row = result.rows[0];
        if (!row) {
          throw new CreateTeacherError('Gagal menyimpan profil Guru.');
        }
        return row.id;
      });

      return { cognitoSub, profileId };
    } catch (error) {
      // KOMPENSASI (strategi (b)): user Cognito telanjur dibuat tetapi langkah
      // setelahnya gagal → hapus user Cognito (best-effort). Transaksi DB sudah
      // di-rollback oleh withTenantTransaction sehingga tidak ada baris profiles
      // persisten → jumlah profil tidak bertambah (Property 5).
      await compensateDeleteCognitoUser(valid.email);

      // Pertahankan pesan domain berbahasa Indonesia bila error memang domain;
      // selain itu bungkus sebagai error undangan generik (R3.4).
      if (error instanceof CreateTeacherError) {
        throw error;
      }
      throw new CreateTeacherError(
        'Gagal menyelesaikan undangan akun Guru. Pembuatan akun dibatalkan. ' +
          'Silakan coba lagi.',
      );
    }
  }

  /**
   * Aktivasi akun Guru satuan/batch dengan kegagalan sebagian (R3.9, R3.10;
   * Property 5).
   *
   * ── Alur (design.md > Alur Aktivasi Akun Guru (A03) > "Aktivasi batch") ──────
   *   1. Deduplikasi `profileIds` agar invarian himpunan (disjoint + union =
   *      input unik) terjaga meski pemanggil mengirim duplikat.
   *   2. Untuk tiap `profileId`, jalankan UPDATE idempoten di bawah RLS:
   *        UPDATE profiles SET activation_status='active', updated_at=now()
   *        WHERE id=$1 AND role='teacher'
   *        RETURNING id
   *      - Baris terupdate (RETURNING ada) → `activated` (termasuk kasus sudah
   *        `active` sebelumnya: UPDATE tetap menyentuh baris → idempoten).
   *      - Tidak ada baris (id tak ditemukan / tak terlihat di bawah RLS / bukan
   *        teacher) → `failed`; status tidak berubah (tetap apa adanya).
   *   3. Kegagalan pada satu akun TIDAK menggagalkan akun lain: tiap akun
   *      diproses pada transaksi terpisah sehingga rollback satu akun tidak
   *      memengaruhi yang lain (R3.10). Error tak terduga pada satu akun →
   *      akun itu masuk `failed`, batch lanjut.
   *
   * Catatan idempotensi: `UPDATE ... WHERE id=$1` pada baris yang sudah `active`
   * tetap mengembalikan baris (RETURNING id) sehingga dilaporkan `activated`
   * tanpa efek samping — memenuhi syarat idempoten pada Property 5.
   */
  async function activateTeachers(
    claims: SessionClaims,
    profileIds: string[],
  ): Promise<ActivationResult> {
    // 1. Deduplikasi menjaga invarian himpunan (Property 5).
    const uniqueIds = Array.from(new Set(profileIds));

    const activated: string[] = [];
    const failed: string[] = [];

    // 2. Proses tiap akun pada transaksi TERPISAH agar kegagalan satu akun tidak
    //    merusak yang lain (R3.10).
    for (const profileId of uniqueIds) {
      try {
        const didActivate = await runInTenantTransaction(claims, async (tx) => {
          const result = await tx.query<{ id: string }>(
            `UPDATE profiles
                SET activation_status = 'active',
                    updated_at = now()
              WHERE id = $1
                AND role = 'teacher'
            RETURNING id`,
            [profileId],
          );
          return result.rowCount !== null && result.rowCount > 0;
        });

        if (didActivate) {
          activated.push(profileId);
        } else {
          // Baris tidak ditemukan / tidak terlihat di bawah RLS / bukan teacher:
          // perlakukan sebagai gagal, status dipertahankan (R3.10).
          failed.push(profileId);
        }
      } catch {
        // Error tak terduga pada satu akun → akun ini gagal (tetap pending),
        // batch tetap lanjut (R3.10). Transaksi akun ini sudah di-rollback.
        failed.push(profileId);
      }
    }

    return { activated, failed };
  }

  /**
   * Kompensasi best-effort: menghapus user Cognito yang telanjur dibuat selama
   * alur undangan yang gagal, agar tidak ada user "menggantung" tanpa profil
   * (menjaga konsistensi Cognito↔DB dan invarian Property 5). Kegagalan
   * penghapusan sengaja DITELAN (diserap) agar tidak menutupi penyebab utama
   * kegagalan undangan yang dilempar ke pemanggil.
   */
  async function compensateDeleteCognitoUser(username: string): Promise<void> {
    try {
      await client.send(
        new AdminDeleteUserCommand({
          UserPoolId: config.userPoolId,
          Username: username,
        }),
      );
    } catch {
      // Sengaja diabaikan: kompensasi bersifat best-effort. Invarian jumlah
      // profil tetap terjaga karena insert profiles hanya pada jalur sukses penuh.
    }
  }

  /**
   * R2 (read side) — daftar seluruh akun Guru + status aktivasi.
   *
   * Dijalankan di bawah RLS via `withTenantTransaction`; kebijakan
   * `profiles_admin_read` (migrasi 0002) mengizinkan admin membaca lintas
   * sekolah. Query diparameterisasi-less (tanpa input pengguna) namun tetap
   * aman — tidak ada interpolasi string. Urutan: `pending` lebih dulu (ASC
   * menempatkan 'active' < 'pending' secara leksikografis? tidak — 'active' <
   * 'pending', jadi dibalik via CASE) lalu nama lengkap.
   */
  async function listTeachers(
    claims: SessionClaims,
  ): Promise<TeacherListItem[]> {
    return runInTenantTransaction(claims, async (tx) => {
      const result = await tx.query<{
        id: string;
        cognito_sub: string;
        email: string;
        full_name: string;
        school_id: string;
        activation_status: string;
      }>(
        `SELECT id, cognito_sub, email, full_name, school_id, activation_status
           FROM profiles
          WHERE role = 'teacher'
          ORDER BY (activation_status = 'active') ASC, full_name ASC`,
      );
      return result.rows.map((row) => ({
        id: row.id,
        cognitoSub: row.cognito_sub,
        email: row.email,
        fullName: row.full_name,
        schoolId: row.school_id,
        activationStatus: row.activation_status,
      }));
    });
  }

  /**
   * R2 (repair side) — adopsi/perbaikan akun Guru dari Cognito. Lihat dokumen
   * kontrak pada {@link TeacherAccountService.adoptCognitoTeacher}.
   *
   * KRITIS (AGENTS.md §1): upsert selalu menyetel/menyisakan
   * `activation_status = 'pending'` dan TIDAK PERNAH mengaktifkan otomatis.
   */
  async function adoptCognitoTeacher(
    claims: SessionClaims,
    input: AdoptCognitoTeacherInput,
  ): Promise<AdoptCognitoTeacherResult> {
    // 1. Validasi bentuk input (reuse skema createTeacher: email/fullName/schoolId).
    const valid = validateInput(input);

    // 2. Verifikasi school_id TERDAFTAR lebih dulu (konsisten dengan createTeacher).
    const exists = await schoolExistsFn(claims, valid.schoolId);
    if (!exists) {
      throw new CreateTeacherError(
        'ID sekolah tidak terdaftar. Akun Guru tidak dapat diadopsi.',
      );
    }

    // 3. AdminGetUser: cari pengguna di Cognito by email (= username).
    let getOutput: AdminGetUserCommandOutput;
    try {
      getOutput = await client.send(
        new AdminGetUserCommand({
          UserPoolId: config.userPoolId,
          Username: valid.email,
        }),
      );
    } catch (error) {
      if (error instanceof Error && error.name === 'UserNotFoundException') {
        throw new CreateTeacherError(
          'Pengguna tidak ditemukan di penyedia identitas.',
        );
      }
      throw new CreateTeacherError(
        'Gagal membaca data pengguna di penyedia identitas. Silakan coba lagi.',
      );
    }

    // 4. Ekstrak `sub` + `custom:school_id` dari atribut get-user.
    const cognitoSub = findAttributeValue(getOutput.UserAttributes, 'sub');
    if (!cognitoSub) {
      throw new CreateTeacherError(
        'Pengguna tidak memiliki identitas (sub) yang valid.',
      );
    }
    const currentSchoolId = findAttributeValue(
      getOutput.UserAttributes,
      COGNITO_SCHOOL_ID_ATTRIBUTE,
    );

    // 5. Set custom:school_id HANYA bila hilang/berbeda.
    if (currentSchoolId !== valid.schoolId) {
      await client.send(
        new AdminUpdateUserAttributesCommand({
          UserPoolId: config.userPoolId,
          Username: valid.email,
          UserAttributes: [
            { Name: COGNITO_SCHOOL_ID_ATTRIBUTE, Value: valid.schoolId },
          ],
        }),
      );
    }

    // 6. Pastikan keanggotaan grup `teacher` (idempoten — menambah anggota yang
    //    sudah tergabung adalah no-op).
    await client.send(
      new AdminAddUserToGroupCommand({
        UserPoolId: config.userPoolId,
        Username: valid.email,
        GroupName: COGNITO_GROUPS.teacher,
      }),
    );

    // 7. Upsert baris `profiles` keyed pada cognito_sub. Status WAJIB `pending`
    //    pada INSERT dan TIDAK disentuh pada DO UPDATE (AGENTS.md §1).
    const profileId = await runInTenantTransaction(claims, async (tx) => {
      const result = await tx.query<{ id: string }>(
        `INSERT INTO profiles
           (cognito_sub, email, full_name, role, school_id, activation_status)
         VALUES ($1, $2, $3, 'teacher', $4, 'pending')
         ON CONFLICT (cognito_sub) DO UPDATE SET
           email = EXCLUDED.email,
           full_name = EXCLUDED.full_name,
           school_id = EXCLUDED.school_id
         RETURNING id`,
        [cognitoSub, valid.email, valid.fullName, valid.schoolId],
      );
      const row = result.rows[0];
      if (!row) {
        throw new CreateTeacherError('Gagal menyimpan profil Guru.');
      }
      return row.id;
    });

    return { cognitoSub, profileId };
  }

  return {
    createTeacher,
    adminInviteTeacher,
    importTeachersCsv,
    activateTeachers,
    listTeachers,
    adoptCognitoTeacher,
  };
}

/* ──────────────────────────────────────────────────────────────────────────
 * Instance default (produksi, lazy)
 * ────────────────────────────────────────────────────────────────────────── */

let defaultTeacherAccountService: TeacherAccountService | undefined;

/**
 * Mengembalikan `teacherAccountService` default (singleton, lazy). Lazy agar
 * konfigurasi environment Cognito hanya dibaca saat benar-benar dipakai.
 */
export function getTeacherAccountService(): TeacherAccountService {
  if (!defaultTeacherAccountService) {
    defaultTeacherAccountService = createTeacherAccountService();
  }
  return defaultTeacherAccountService;
}
