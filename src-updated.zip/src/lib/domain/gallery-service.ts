/**
 * `galleryService` — Galeri Kegiatan STEM 2024–2026 publik (public-showcase R3).
 * Baca publik via `withPublicTransaction` (RLS gallery_public_read = true).
 *
 * _Requirements: 3.1, 3.2_
 */

import 'server-only';

import type { SessionClaims } from '@/lib/auth/types';
import { withPublicTransaction } from '@/lib/db/public-transaction';
import { withTenantTransaction } from '@/lib/db/tenant-transaction';

export interface GalleryItem {
  id: string;
  year: number;
  title: string;
  caption: string | null;
  imageUrl: string | null;
  createdAt: Date;
}

/** Daftar item galeri; filter tahun opsional (R3.1, R3.2). */
export async function listGallery(year?: number): Promise<GalleryItem[]> {
  return withPublicTransaction(async (tx) => {
    const params: number[] = [];
    let where = '';
    if (year && Number.isInteger(year)) {
      params.push(year);
      where = `WHERE year = $1`;
    }
    const res = await tx.query(
      `SELECT id, year, title, caption, image_url, created_at
         FROM stem_gallery_items ${where}
        ORDER BY year DESC, created_at DESC`,
      params,
    );
    return res.rows.map((r: Record<string, unknown>) => ({
      id: r.id as string,
      year: r.year as number,
      title: r.title as string,
      caption: (r.caption as string | null) ?? null,
      imageUrl: (r.image_url as string | null) ?? null,
      createdAt: r.created_at as Date,
    }));
  });
}

/* ── Admin: kelola Galeri (public-showcase revisi) ─────────────────────────
 * Admin menerbitkan item galeri (tahun, judul, caption, gambar). Tulis admin
 * via withTenantTransaction (RLS gallery_admin_insert/update). Phase 1: gambar
 * opsional; Phase 2 menambahkan unggah foto ke S3 publik.
 */

export interface CreateGalleryInput {
  year: number;
  title: string;
  caption?: string;
  imageBucket?: string;
  imageKey?: string;
  imageUrl?: string;
}

export class GalleryError extends Error {}

/** ADMIN: daftar seluruh item galeri untuk kelola. */
export async function listGalleryForAdmin(
  claims: SessionClaims,
): Promise<GalleryItem[]> {
  return withTenantTransaction(claims, async (tx) => {
    const res = await tx.query(
      `SELECT id, year, title, caption, image_url, created_at
         FROM stem_gallery_items ORDER BY year DESC, created_at DESC`,
    );
    return res.rows.map((r: Record<string, unknown>) => ({
      id: r.id as string,
      year: r.year as number,
      title: r.title as string,
      caption: (r.caption as string | null) ?? null,
      imageUrl: (r.image_url as string | null) ?? null,
      createdAt: r.created_at as Date,
    }));
  });
}

/** ADMIN: terbitkan item galeri baru. */
export async function createGalleryItem(
  claims: SessionClaims,
  input: CreateGalleryInput,
): Promise<string> {
  return withTenantTransaction(claims, async (tx) => {
    const res = await tx.query<{ id: string }>(
      `INSERT INTO stem_gallery_items
         (year, title, caption, image_bucket, image_key, image_url)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
      [
        input.year,
        input.title,
        input.caption ?? null,
        input.imageBucket ?? null,
        input.imageKey ?? null,
        input.imageUrl ?? null,
      ],
    );
    const row = res.rows[0];
    if (!row) throw new GalleryError('Gagal menerbitkan item galeri.');
    return row.id;
  });
}
