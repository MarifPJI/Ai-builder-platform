/**
 * Helper Amazon S3 Presigned URL (HANYA sisi server) — fitur course-class-publishing.
 *
 * Dipakai untuk berkas Materi (A07 unggah oleh Admin, T03 unduh oleh Guru):
 * byte berkas mengalir LANGSUNG antara browser dan S3 memakai URL berbatas waktu,
 * tidak melewati server Fargate.
 *
 * Keamanan (R1.3, R3.2, R8.4):
 * - `import 'server-only'` mencegah modul ini ter-bundle ke Client Component.
 * - Kredensial IAM di-resolve oleh rantai kredensial AWS default (task role ECS
 *   `aibuilder-ecs-task-role` di produksi). TIDAK ada kredensial di-hardcode.
 * - Bucket `aibuilder-private-assets-prod` bersifat PRIVAT (Block Public Access
 *   ON); akses hanya melalui presigned URL berbatas waktu.
 * - Masa berlaku URL maksimum 300 detik.
 *
 * _Requirements: 1.3, 3.2, 8.4_
 */

import 'server-only';

import { randomUUID } from 'node:crypto';

import {
  GetObjectCommand,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

/** Region default (selaras dengan auth/cognito: Singapore). */
const DEFAULT_REGION = 'ap-southeast-1' as const;

/** Masa berlaku presigned URL — maksimum 300 detik (R1.3, R3.2). */
export const PRESIGN_EXPIRES_SEC = 300 as const;

/** Bucket privat berkas Materi. Dapat dioverride via env untuk fleksibilitas. */
export const PRIVATE_BUCKET =
  process.env.S3_PRIVATE_BUCKET?.trim() || 'aibuilder-private-assets-prod';

/** Tipe konten berkas Materi yang diizinkan diunggah (R1.4). */
export const ALLOWED_UPLOAD_CONTENT_TYPES = {
  pdf: 'application/pdf',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
} as const;

export type UploadContentType =
  (typeof ALLOWED_UPLOAD_CONTENT_TYPES)[keyof typeof ALLOWED_UPLOAD_CONTENT_TYPES];

/**
 * Tipe konten foto dokumentasi sesi (T06B). Satu nilai literal `image/jpeg`
 * (Decision 6): jalur tangkap kamera hanya meng-encode JPEG, sehingga format
 * lain (mis. PNG) tak terjangkau dan tidak dimodelkan sebagai union.
 */
export type ImageContentType = 'image/jpeg';

/**
 * Hasil presign PUT: URL unggah + `s3Key` yang HARUS dicatat ke basis data saat
 * unggah dikonfirmasi (confirmFileUpload).
 */
export interface PresignPutResult {
  url: string;
  bucket: string;
  s3Key: string;
  expiresInSec: number;
}

function resolveRegion(): string {
  return (
    process.env.APP_AWS_REGION?.trim() ||
    process.env.AWS_REGION?.trim() ||
    DEFAULT_REGION
  );
}

/**
 * Singleton klien S3 (lazy) pada globalThis untuk menghindari pembuatan berulang
 * akibat HMR dalam pengembangan Next.js.
 */
const globalForS3 = globalThis as typeof globalThis & {
  __identityS3Client__?: S3Client;
};

function getS3Client(): S3Client {
  if (!globalForS3.__identityS3Client__) {
    globalForS3.__identityS3Client__ = new S3Client({ region: resolveRegion() });
  }
  return globalForS3.__identityS3Client__;
}

/**
 * Membuat `s3Key` unik & aman untuk objek Materi. `keyPrefix` mis. `materials/<id>`.
 * Nama berkas tidak dipakai langsung sebagai key (hindari path traversal / tabrakan);
 * disimpan terpisah sebagai metadata pada basis data.
 */
function buildKey(keyPrefix: string, ext: string): string {
  const safePrefix = keyPrefix.replace(/[^a-zA-Z0-9/_-]/g, '').replace(/^\/+|\/+$/g, '');
  return `${safePrefix}/${randomUUID()}.${ext}`;
}

/**
 * Menerbitkan Presigned PUT URL untuk mengunggah berkas Materi ke bucket privat.
 * Hanya menerima tipe konten yang diizinkan (R1.4). Mengembalikan `s3Key` untuk
 * dicatat ke basis data setelah unggah dikonfirmasi (R1.3).
 */
export async function presignPut(
  contentType: UploadContentType,
  keyPrefix: string,
): Promise<PresignPutResult> {
  const ext = contentType === ALLOWED_UPLOAD_CONTENT_TYPES.pdf ? 'pdf' : 'pptx';
  const s3Key = buildKey(keyPrefix, ext);

  const command = new PutObjectCommand({
    Bucket: PRIVATE_BUCKET,
    Key: s3Key,
    ContentType: contentType,
  });

  const url = await getSignedUrl(getS3Client(), command, {
    expiresIn: PRESIGN_EXPIRES_SEC,
  });

  return {
    url,
    bucket: PRIVATE_BUCKET,
    s3Key,
    expiresInSec: PRESIGN_EXPIRES_SEC,
  };
}

/**
 * Menerbitkan Presigned PUT URL untuk mengunggah foto dokumentasi sesi (T06B)
 * ke bucket privat. Hanya menerima tipe konten gambar `image/jpeg`
 * (Decision 6) dan selalu memakai ekstensi `jpg`. Mengembalikan `s3Key` untuk
 * dicatat ke basis data setelah unggah dikonfirmasi (confirmSessionPhoto).
 *
 * Menggunakan kembali `buildKey`/`getS3Client`/`PRIVATE_BUCKET`/
 * `PRESIGN_EXPIRES_SEC` yang sama dengan unggah Materi; `ContentType` presign
 * disetel ke `contentType` sehingga header PUT klien WAJIB cocok persis.
 */
export async function presignPutImage(
  contentType: ImageContentType,
  keyPrefix: string,
): Promise<PresignPutResult> {
  const s3Key = buildKey(keyPrefix, 'jpg');

  const command = new PutObjectCommand({
    Bucket: PRIVATE_BUCKET,
    Key: s3Key,
    ContentType: contentType,
  });

  const url = await getSignedUrl(getS3Client(), command, {
    expiresIn: PRESIGN_EXPIRES_SEC,
  });

  return {
    url,
    bucket: PRIVATE_BUCKET,
    s3Key,
    expiresInSec: PRESIGN_EXPIRES_SEC,
  };
}

/**
 * Menerbitkan Presigned GET URL untuk mengunduh berkas Materi (R3.2). Pemanggil
 * (materialService) WAJIB memastikan Material berstatus `published` sebelum
 * memanggil ini (R3.5).
 */
export async function presignGet(s3Key: string): Promise<string> {
  const command = new GetObjectCommand({
    Bucket: PRIVATE_BUCKET,
    Key: s3Key,
  });
  return getSignedUrl(getS3Client(), command, {
    expiresIn: PRESIGN_EXPIRES_SEC,
  });
}
