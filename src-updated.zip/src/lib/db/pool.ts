/**
 * pg Pool untuk Amazon RDS for PostgreSQL (hanya sisi server).
 *
 * Ikhtisar (lihat design.md > Components and Interfaces > DB access layer):
 * - Koneksi memakai `DATABASE_URL` berbasis role least-privilege `app_runtime`
 *   (NOSUPERUSER, NOBYPASSRLS) — lihat `db/migrations/0003_app_runtime_role.sql`.
 * - Secret `DATABASE_URL` HANYA dibaca di sisi server dan tidak pernah dikirim
 *   ke klien browser (R6.1). Kredensial TIDAK di-hardcode.
 *
 * Guard sisi server:
 *   `import 'server-only'` menyebabkan build GAGAL bila modul ini tidak sengaja
 *   terimpor ke dalam bundel Client Component. Paket `server-only` di-resolve
 *   oleh Next.js saat build.
 *
 * _Requirements: 4.1, 6.1_
 */

import 'server-only';

import { readFileSync } from 'node:fs';
import { join } from 'node:path';

import { Pool } from 'pg';

/**
 * Membaca CA bundle Amazon RDS (PEM) untuk verifikasi TLS penuh.
 *
 * Urutan sumber:
 *   1. `RDS_CA_BUNDLE` (env) — bila diisi berisi PEM langsung (opsional override).
 *   2. Berkas repo `certs/rds-global-bundle.pem` — CA PUBLIK Amazon RDS
 *      (aman di-commit, bukan secret). Ini jalur utama: menghindari masalah
 *      newline pada env var multi-baris.
 *
 * Mengembalikan `undefined` bila tidak ada sumber (maka pool memakai mode
 * terenkripsi-tanpa-verifikasi sebagai fallback — lihat createPool).
 */
function readRdsCaBundle(): string | undefined {
  const fromEnv = process.env.RDS_CA_BUNDLE?.trim();
  if (fromEnv) {
    return fromEnv;
  }
  try {
    // process.cwd() = root aplikasi saat runtime SSR; berkas CA di certs/.
    const pem = readFileSync(
      join(process.cwd(), 'certs', 'rds-global-bundle.pem'),
      'utf8',
    ).trim();
    return pem.length > 0 ? pem : undefined;
  } catch {
    // Berkas tidak ada / tak terbaca → fallback ke mode tanpa verifikasi.
    return undefined;
  }
}

/**
 * Membaca `DATABASE_URL` dari environment sisi server.
 * Dilempar bila tidak tersetel agar kegagalan konfigurasi terdeteksi dini
 * (fail-fast) alih-alih menghasilkan koneksi tanpa kredensial.
 */
function readDatabaseUrl(): string {
  const url = process.env.DATABASE_URL;
  if (!url || url.trim().length === 0) {
    throw new Error(
      'DATABASE_URL belum tersetel. Variabel ini hanya dibaca di sisi server ' +
        'dan wajib memakai role least-privilege `app_runtime`.',
    );
  }
  return url;
}

/**
 * Cache singleton pada globalThis.
 *
 * Alasan: dalam mode pengembangan Next.js, modul dapat dievaluasi ulang akibat
 * Hot Module Replacement. Menyimpan Pool pada globalThis mencegah kebocoran
 * koneksi karena pembuatan Pool berulang-ulang pada setiap reload.
 */
const globalForPool = globalThis as typeof globalThis & {
  __identityTenancyPgPool__?: Pool;
};

/**
 * Membuat instance Pool baru dari `DATABASE_URL`.
 *
 * ── TLS ke Amazon RDS ────────────────────────────────────────────────────────
 * RDS memaksa koneksi terenkripsi (connection string memakai `sslmode=require`),
 * namun sertifikat server RDS ditandatangani oleh **Amazon RDS root CA** yang
 * TIDAK ada pada daftar CA tepercaya bawaan Node.js. Akibatnya `pg` menolak
 * dengan `SELF_SIGNED_CERT_IN_CHAIN`.
 *
 * Solusi yang BENAR & AMAN (Fix A): memverifikasi sertifikat terhadap CA bundle
 * Amazon RDS. Bila berkas CA tersedia (via env `RDS_CA_BUNDLE` berisi PEM, mis.
 * di-inject saat build), kita pakai itu dengan verifikasi penuh
 * (`rejectUnauthorized: true`).
 *
 * Solusi PRAGMATIS sementara (Fix B, default saat ini): bila CA bundle belum
 * disediakan, koneksi TETAP dienkripsi (SSL ON) namun verifikasi rantai CA
 * dilonggarkan (`rejectUnauthorized: false`). Ini menghilangkan error dan
 * menjaga kerahasiaan transport di dalam jaringan AWS, TETAPI tidak melindungi
 * dari MITM yang memalsukan sertifikat. HARUS di-hardening ke Fix A (sediakan
 * `RDS_CA_BUNDLE`) sebelum produksi dengan data siswa — konsisten dengan catatan
 * hardening Opsi 1 di docs/AWS_Architecture_and_Deployment_Guide.md.
 */
function createPool(): Pool {
  const caBundle = readRdsCaBundle();

  const ssl = caBundle
    ? // Fix A: verifikasi penuh terhadap CA Amazon RDS.
      { ca: caBundle, rejectUnauthorized: true as const }
    : // Fix B: terenkripsi namun tanpa verifikasi rantai CA (sementara).
      { rejectUnauthorized: false as const };

  // Log satu kali saat pool dibuat, menandai mode TLS yang dipilih. Memudahkan
  // verifikasi di Hosting compute logs apakah verifikasi CA aktif. Tidak
  // mencetak secret apa pun.
  console.log(
    `[db] RDS TLS mode: ${
      caBundle ? 'verified (CA bundle loaded)' : 'encrypted-only (no CA — fallback)'
    }`,
  );

  // CATATAN penting perilaku node-postgres:
  // Bila connection string memuat `sslmode=require`, `pg` dapat menyusun konfigurasi
  // SSL sendiri dari URL dan MENGABAIKAN/berkonflik dengan objek `ssl` di bawah,
  // sehingga `rejectUnauthorized: false` tidak berlaku dan error
  // SELF_SIGNED_CERT_IN_CHAIN tetap muncul. Karena itu kita HAPUS parameter
  // `sslmode` dari URL dan mengandalkan SEPENUHNYA objek `ssl` eksplisit ini.
  // Koneksi tetap terenkripsi (ssl diset), hanya verifikasi CA yang dikendalikan
  // oleh objek `ssl` (bukan oleh string URL).
  const rawUrl = readDatabaseUrl();
  const urlWithoutSslMode = rawUrl
    .replace(/([?&])sslmode=[^&]*(&|$)/i, (_m, pre: string, post: string) =>
      post === '&' ? pre : '',
    )
    .replace(/[?&]$/, '');

  return new Pool({
    connectionString: urlWithoutSslMode,
    ssl,
  });
}

/**
 * Mengembalikan pg Pool singleton (lazy-initialized).
 *
 * Pool bersifat malas: koneksi fisik baru dibuka saat query pertama dijalankan,
 * sehingga mengimpor modul ini tidak langsung menyentuh basis data.
 */
export function getPool(): Pool {
  if (!globalForPool.__identityTenancyPgPool__) {
    globalForPool.__identityTenancyPgPool__ = createPool();
  }
  return globalForPool.__identityTenancyPgPool__;
}
