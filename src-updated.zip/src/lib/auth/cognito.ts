/**
 * Klien & konfigurasi Amazon Cognito (HANYA sisi server).
 *
 * Ikhtisar (lihat design.md > Architecture > Komponen Arsitektural dan diagram
 * arsitektur tingkat tinggi):
 * - Amazon Cognito User Pool menyediakan autentikasi dua peran di region
 *   `ap-southeast-3` (Jakarta).
 * - User Pool dikonfigurasi dengan DUA grup peran (`admin`, `teacher`), atribut
 *   kustom `custom:school_id`, dan **self sign-up DIMATIKAN** (R1.6).
 * - Operasi administratif (AdminCreateUser, AdminAddUserToGroup, dll.) dijalankan
 *   dari sisi server memakai klien ini.
 *
 * Keamanan kredensial (R6.1, R6.2):
 * - `import 'server-only'` menyebabkan build GAGAL bila modul ini tidak sengaja
 *   terimpor ke dalam bundel Client Component.
 * - Seluruh konfigurasi (region, User Pool ID, Client ID, Client Secret opsional)
 *   dibaca dari environment SISI SERVER saja. TIDAK ada kredensial/secret yang
 *   di-hardcode. Kredensial IAM untuk SDK di-resolve oleh rantai kredensial AWS
 *   default (IAM Role di produksi; variabel lingkungan untuk pengembangan lokal).
 *
 * _Requirements: 1.6, 2.4, 6.1, 6.2_
 */

import 'server-only';

import { CognitoIdentityProviderClient } from '@aws-sdk/client-cognito-identity-provider';

import type { Role } from './types';

/**
 * Region AWS default untuk seluruh program (Singapore). Dipakai bila variabel
 * region tidak tersetel di environment.
 *
 * CATATAN REGION & AMPLIFY: hosting dipindah ke `ap-southeast-1` (Singapore)
 * karena Amplify/App Runner tidak tersedia di `ap-southeast-3` (Jakarta).
 * Selain itu, AWS Amplify MELARANG environment variable berprefiks `AWS`
 * ("Environment variables cannot start with the reserved prefix AWS"), sehingga
 * region dibaca dari `APP_AWS_REGION` (bukan `AWS_REGION`). Pada runtime AWS,
 * SDK juga menyetel `AWS_REGION` secara otomatis, yang dipakai sebagai cadangan.
 */
export const DEFAULT_AWS_REGION = 'ap-southeast-1' as const;

/**
 * Membaca region dari environment dengan urutan preferensi:
 *   1. `APP_AWS_REGION` — variabel yang kita set di Amplify (prefiks AWS dilarang).
 *   2. `AWS_REGION`     — otomatis diset oleh runtime/SDK AWS (mis. di Amplify).
 *   3. `DEFAULT_AWS_REGION` — cadangan terakhir (`ap-southeast-1`).
 */
function resolveRegion(): string {
  return (
    process.env.APP_AWS_REGION?.trim() ||
    process.env.AWS_REGION?.trim() ||
    DEFAULT_AWS_REGION
  );
}

/**
 * Nama dua grup Cognito User Pool. Konsisten dengan `Role` dan CHECK constraint
 * `role IN ('admin','teacher')` pada tabel `profiles`.
 *
 * Catatan: grup dibuat di sisi infrastruktur/Cognito; konstanta ini adalah
 * referensi kanonis yang dipakai kode aplikasi saat menetapkan/memeriksa grup.
 */
export const COGNITO_GROUPS: Readonly<Record<Role, string>> = Object.freeze({
  admin: 'admin',
  teacher: 'teacher',
});

/**
 * Daftar grup yang valid (dipakai untuk iterasi/validasi penetapan grup).
 */
export const COGNITO_GROUP_NAMES: readonly string[] = Object.freeze([
  COGNITO_GROUPS.admin,
  COGNITO_GROUPS.teacher,
]);

/**
 * Nama atribut kustom Cognito yang menyimpan `school_id` Guru. Nilai atribut ini
 * harus konsisten dengan kolom `school_id` pada tabel `profiles` (Property 1 —
 * isolasi tenancy). Server mengunci `school_id` dari atribut/klaim ini, bukan
 * dari input klien (R1.3).
 */
export const COGNITO_SCHOOL_ID_ATTRIBUTE = 'custom:school_id' as const;

/**
 * Properti konfigurasi User Pool: self sign-up DIMATIKAN (R1.6).
 *
 * Ini adalah properti infrastruktur Cognito (`AdminCreateUserConfig
 * .AllowAdminCreateUserOnly = true`) — akun hanya dibuat oleh Admin via `A03`,
 * tidak ada pendaftaran mandiri di `U01`. Konstanta ini menegaskan ekspektasi
 * tersebut di tingkat kode sebagai dokumentasi + titik pemeriksaan; penegakan
 * sesungguhnya berada di definisi User Pool (infra/Cognito).
 */
export const SELF_SIGN_UP_ENABLED = false as const;

/**
 * Konfigurasi Cognito yang dibaca dari environment sisi server.
 * `clientSecret` opsional: hanya terisi bila App Client memakai client secret.
 */
export interface CognitoConfig {
  /** Region AWS tempat User Pool berada. */
  readonly region: string;
  /** ID Amazon Cognito User Pool. */
  readonly userPoolId: string;
  /** ID App Client yang dipakai untuk alur autentikasi. */
  readonly clientId: string;
  /** Client secret App Client, bila dikonfigurasi (sisi server saja). */
  readonly clientSecret: string | undefined;
}

/**
 * Melempar bila sebuah variabel lingkungan wajib tidak tersetel. Fail-fast agar
 * kesalahan konfigurasi terdeteksi dini, bukan menghasilkan klien yang tidak
 * fungsional saat runtime.
 */
function requireEnv(name: string): string {
  const value = process.env[name];
  if (value === undefined || value.trim().length === 0) {
    throw new Error(
      `${name} belum tersetel. Variabel konfigurasi Cognito ini hanya dibaca ` +
        'di sisi server dan tidak boleh di-hardcode.',
    );
  }
  return value;
}

/**
 * Membaca konfigurasi Cognito dari environment sisi server.
 *
 * - Region dibaca via `resolveRegion()` (`APP_AWS_REGION` → `AWS_REGION` →
 *   default `ap-southeast-1`). Catatan: Amplify melarang prefiks `AWS`, jadi
 *   variabel yang kita set bernama `APP_AWS_REGION`.
 * - `COGNITO_USER_POOL_ID` dan `COGNITO_CLIENT_ID` wajib.
 * - `COGNITO_CLIENT_SECRET` opsional (hanya bila App Client memakai secret).
 *
 * Seluruh nilai berasal dari environment; TIDAK ada secret yang di-hardcode.
 */
export function readCognitoConfig(): CognitoConfig {
  const region = resolveRegion();
  const secret = process.env.COGNITO_CLIENT_SECRET?.trim();

  return {
    region,
    userPoolId: requireEnv('COGNITO_USER_POOL_ID'),
    clientId: requireEnv('COGNITO_CLIENT_ID'),
    clientSecret: secret && secret.length > 0 ? secret : undefined,
  };
}

/**
 * Cache singleton pada globalThis untuk menghindari pembuatan klien berulang
 * akibat Hot Module Replacement dalam mode pengembangan Next.js.
 */
const globalForCognito = globalThis as typeof globalThis & {
  __identityTenancyCognitoClient__?: CognitoIdentityProviderClient;
};

/**
 * Mengembalikan `CognitoIdentityProviderClient` singkat (lazy-initialized).
 *
 * Region diambil via `resolveRegion()` (`APP_AWS_REGION` → `AWS_REGION` →
 * default `ap-southeast-1`). Kredensial IAM TIDAK disetel di sini: SDK memakai
 * rantai kredensial AWS default (IAM Role di produksi), sehingga tidak ada
 * secret yang di-hardcode pada kode aplikasi.
 */
export function getCognitoClient(): CognitoIdentityProviderClient {
  if (!globalForCognito.__identityTenancyCognitoClient__) {
    const region = resolveRegion();
    globalForCognito.__identityTenancyCognitoClient__ =
      new CognitoIdentityProviderClient({ region });
  }
  return globalForCognito.__identityTenancyCognitoClient__;
}
