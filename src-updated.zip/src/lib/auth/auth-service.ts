/**
 * Auth_Service — pembungkus Amazon Cognito untuk autentikasi dua peran.
 *
 * Mengimplementasikan tiga operasi inti (lihat design.md > Components and
 * Interfaces > Auth_Service, serta diagram "Alur Autentikasi (U01)"):
 *
 * - `signIn(email, password)`   — verifikasi kredensial (R1.1), pesan GENERIK
 *   untuk kegagalan (R1.4), dan lockout 5x gagal berturut per email selama
 *   minimum 15 menit (R1.5).
 * - `completeNewPassword(session, newPassword)` — menyelesaikan challenge
 *   `NEW_PASSWORD_REQUIRED` pada login pertama (R1.8); menolak kata sandi di
 *   luar 8–128 karakter via `newPasswordSchema` (R1.9).
 * - `verifyToken(jwt)` — verifikasi tanda tangan & klaim token JWT Cognito
 *   melalui JWKS, lalu mengekstrak `role` dari `cognito:groups` dan `schoolId`
 *   dari klaim `custom:school_id`. Peran & `schoolId` SELALU berasal dari token;
 *   input klien DIABAIKAN (R1.2/R1.3, Property 3).
 *
 * ── Pilihan alur autentikasi Cognito ────────────────────────────────────────
 * Memakai **AdminInitiateAuth** dengan flow `ADMIN_USER_PASSWORD_AUTH`
 * (bukan `InitiateAuth` dari sisi klien). Alasan:
 *   1. Seluruh verifikasi kredensial terjadi di sisi server — kata sandi tidak
 *      pernah ditangani di browser (sejalan dengan R6.1 dan arsitektur pada
 *      design.md: Server Actions/Route Handlers server-side).
 *   2. Mendukung challenge `NEW_PASSWORD_REQUIRED` untuk alur
 *      FORCE_CHANGE_PASSWORD (R1.8), diselesaikan via `AdminRespondToAuthChallenge`.
 *   3. Konsisten dengan operasi administratif lain (AdminCreateUser dkk.) yang
 *      sudah dipakai fitur ini.
 * Catatan infra: flow `ADMIN_USER_PASSWORD_AUTH` harus diaktifkan pada App Client
 * Cognito (`ExplicitAuthFlows`). Bila App Client memakai client secret, maka
 * `SECRET_HASH` dihitung dan disertakan (lihat `computeSecretHash`).
 *
 * ── Lockout store ────────────────────────────────────────────────────────────
 * Penghitung kegagalan login per email disimpan pada sebuah store yang dapat
 * di-inject. Implementasi default adalah **in-memory `Map`** (`InMemoryLockoutStore`).
 * PERHATIAN: store in-memory TIDAK persisten dan TIDAK terbagi antar instance —
 * hitungan hilang saat proses restart dan tidak berlaku lintas beberapa instance
 * server. Untuk produksi, lockout WAJIB memakai store terbagi & tahan-restart
 * (mis. Redis/Amazon ElastiCache atau Amazon DynamoDB dengan TTL). Store dan
 * clock sengaja dibuat injectable agar perilaku lockout dapat diuji deterministik
 * (dipakai task PBT 7.3).
 *
 * _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.8, 1.9_
 */

import 'server-only';

import { createHmac } from 'node:crypto';

import {
  AdminInitiateAuthCommand,
  AdminRespondToAuthChallengeCommand,
  type AdminInitiateAuthCommandOutput,
  type AdminRespondToAuthChallengeCommandOutput,
  type CognitoIdentityProviderClient,
} from '@aws-sdk/client-cognito-identity-provider';
import { CognitoJwtVerifier } from 'aws-jwt-verify';

import { newPasswordSchema } from '../validation/auth';

import {
  COGNITO_GROUPS,
  COGNITO_SCHOOL_ID_ATTRIBUTE,
  getCognitoClient,
  readCognitoConfig,
  type CognitoConfig,
} from './cognito';
import type { Role, SessionClaims } from './types';

/* ──────────────────────────────────────────────────────────────────────────
 * Konstanta kebijakan lockout (R1.5)
 * ────────────────────────────────────────────────────────────────────────── */

/** Jumlah kegagalan login berturut yang memicu penguncian. */
export const MAX_FAILED_ATTEMPTS = 5;

/** Durasi penguncian minimum setelah ambang kegagalan tercapai (menit). */
export const LOCKOUT_DURATION_MINUTES = 15;

const LOCKOUT_DURATION_MS = LOCKOUT_DURATION_MINUTES * 60 * 1000;

/* ──────────────────────────────────────────────────────────────────────────
 * Kontrak hasil (sesuai design.md: SignInResult union)
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Hasil upaya masuk / penggantian kata sandi.
 *
 * - `ok` — autentikasi berhasil; `jwt` adalah ID token terverifikasi-nanti oleh
 *   Session_Guard.
 * - `force_change_password` — Cognito meminta kata sandi baru (login pertama);
 *   `session` dipakai untuk menyelesaikan challenge via `completeNewPassword`.
 * - `invalid_credentials` — kredensial tidak cocok; pesan WAJIB generik (R1.4).
 * - `account_locked` — email terkunci sementara; `retryAfterMinutes` menyatakan
 *   sisa waktu (minimum) sebelum boleh mencoba lagi (R1.5).
 */
export type SignInResult =
  | { status: 'ok'; jwt: string }
  | { status: 'force_change_password'; session: string }
  | { status: 'invalid_credentials' }
  | { status: 'account_locked'; retryAfterMinutes: number }
  // Kata sandi baru ditolak Cognito karena tidak memenuhi KEBIJAKAN SANDI
  // User Pool (mis. wajib huruf besar/kecil, angka, simbol) — BUKAN kredensial
  // salah dan BUKAN sekadar panjang. Dipisah agar UI bisa menampilkan aturan
  // sandi, bukan melempar 500. (InvalidPasswordException/InvalidParameterException).
  | { status: 'password_policy_unmet' };

/* ──────────────────────────────────────────────────────────────────────────
 * Clock & Lockout store yang dapat di-inject (agar dapat diuji — task 7.3)
 * ────────────────────────────────────────────────────────────────────────── */

/** Abstraksi waktu agar lockout dapat diuji deterministik. */
export interface Clock {
  /** Waktu saat ini dalam milidetik sejak epoch (UTC). */
  now(): number;
}

/** Clock default berbasis jam sistem. */
export const systemClock: Clock = {
  now: () => Date.now(),
};

/** Catatan kegagalan login untuk satu email. */
interface LockoutRecord {
  /** Jumlah kegagalan berturut sejak keberhasilan/terakhir reset. */
  failures: number;
  /** Epoch ms kapan penguncian berakhir; `null` bila tidak terkunci. */
  lockedUntil: number | null;
}

/**
 * Store penghitung lockout. Dibuat sebagai antarmuka agar implementasi produksi
 * (Redis/DynamoDB) dapat menggantikan default in-memory tanpa mengubah
 * Auth_Service.
 */
export interface LockoutStore {
  get(email: string): LockoutRecord | undefined;
  set(email: string, record: LockoutRecord): void;
  delete(email: string): void;
}

/**
 * Implementasi lockout store berbasis `Map` in-memory.
 *
 * PERHATIAN: TIDAK persisten dan TIDAK terbagi antar instance (lihat catatan di
 * header modul). Cocok untuk pengembangan/pengujian; produksi membutuhkan store
 * terbagi & tahan-restart.
 */
export class InMemoryLockoutStore implements LockoutStore {
  private readonly records = new Map<string, LockoutRecord>();

  get(email: string): LockoutRecord | undefined {
    return this.records.get(email);
  }

  set(email: string, record: LockoutRecord): void {
    this.records.set(email, record);
  }

  delete(email: string): void {
    this.records.delete(email);
  }
}

/* ──────────────────────────────────────────────────────────────────────────
 * Verifier JWT (JWKS) — di-cache per (userPoolId, clientId)
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Tipe minimal verifier JWT Cognito yang dibutuhkan Auth_Service. Memungkinkan
 * penyuntikan verifier tiruan pada pengujian.
 */
export interface CognitoTokenVerifier {
  verify(token: string): Promise<Record<string, unknown>>;
}

const globalForVerifier = globalThis as typeof globalThis & {
  __identityTenancyJwtVerifier__?: {
    key: string;
    verifier: CognitoTokenVerifier;
  };
};

/**
 * Membuat (atau memakai ulang) verifier `aws-jwt-verify` untuk ID token Cognito.
 * JWKS diambil & di-cache otomatis oleh pustaka. Di-cache pada `globalThis` agar
 * tidak dibuat ulang saat Hot Module Replacement.
 */
function getDefaultVerifier(config: CognitoConfig): CognitoTokenVerifier {
  const key = `${config.userPoolId}:${config.clientId}`;
  const cached = globalForVerifier.__identityTenancyJwtVerifier__;
  if (cached && cached.key === key) {
    return cached.verifier;
  }

  const verifier = CognitoJwtVerifier.create({
    userPoolId: config.userPoolId,
    clientId: config.clientId,
    tokenUse: 'id',
  }) as unknown as CognitoTokenVerifier;

  globalForVerifier.__identityTenancyJwtVerifier__ = { key, verifier };
  return verifier;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Util internal
 * ────────────────────────────────────────────────────────────────────────── */

/**
 * Menghitung `SECRET_HASH` Cognito bila App Client memakai client secret.
 * Formula resmi: Base64(HMAC-SHA256(key = clientSecret, message = username + clientId)).
 * Mengembalikan `undefined` bila tidak ada client secret.
 */
function computeSecretHash(
  username: string,
  config: CognitoConfig,
): string | undefined {
  if (!config.clientSecret) {
    return undefined;
  }
  return createHmac('sha256', config.clientSecret)
    .update(username + config.clientId)
    .digest('base64');
}

/**
 * Menormalkan email untuk kunci lockout agar penghitungan konsisten terlepas
 * dari kapitalisasi/spasi tepi.
 */
function lockoutKey(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Menentukan apakah error dari Cognito menandakan kredensial tidak valid
 * (dipetakan ke pesan generik R1.4). Baik user tidak ditemukan maupun kata sandi
 * salah DIPERLAKUKAN SAMA agar tidak membocorkan email vs sandi.
 */
function isInvalidCredentialsError(error: unknown): boolean {
  return (
    errorName(error) === 'NotAuthorizedException' ||
    errorName(error) === 'UserNotFoundException'
  );
}

/** Nama error SDK AWS (atau '' bila tak ada). */
function errorName(error: unknown): string {
  return error && typeof error === 'object' && 'name' in error
    ? String((error as { name: unknown }).name)
    : '';
}

/**
 * Menentukan apakah error Cognito menandakan kata sandi baru menyalahi KEBIJAKAN
 * SANDI User Pool (bukan kredensial salah). Cognito melempar ini saat
 * menyelesaikan challenge NEW_PASSWORD_REQUIRED dengan sandi yang lolos cek
 * panjang aplikasi namun gagal aturan pool (huruf besar/kecil, angka, simbol).
 * Tanpa penanganan ini error akan merambat sebagai 500 (server-side exception).
 */
function isPasswordPolicyError(error: unknown): boolean {
  const name = errorName(error);
  return (
    name === 'InvalidPasswordException' ||
    name === 'InvalidParameterException'
  );
}

/**
 * Mengekstrak ID token dari hasil autentikasi. Session_Guard yang akan
 * memverifikasi tanda tangan & klaim; di sini hanya pengambilan nilai mentah.
 */
function extractIdToken(
  output:
    | AdminInitiateAuthCommandOutput
    | AdminRespondToAuthChallengeCommandOutput,
): string | undefined {
  return output.AuthenticationResult?.IdToken ?? undefined;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Konstruksi Auth_Service (dependency injection untuk pengujian)
 * ────────────────────────────────────────────────────────────────────────── */

/** Dependensi Auth_Service; seluruhnya opsional dengan default produksi. */
export interface AuthServiceDeps {
  readonly client?: CognitoIdentityProviderClient;
  readonly config?: CognitoConfig;
  readonly clock?: Clock;
  readonly lockoutStore?: LockoutStore;
  readonly verifier?: CognitoTokenVerifier;
}

/** Kontrak publik Auth_Service (bagian yang diimplementasikan task 7.2). */
export interface AuthService {
  signIn(email: string, password: string): Promise<SignInResult>;
  completeNewPassword(
    session: string,
    newPassword: string,
    email?: string,
  ): Promise<SignInResult>;
  verifyToken(jwt: string): Promise<SessionClaims>;
}

/**
 * Membuat instance Auth_Service. Tanpa argumen, memakai klien & konfigurasi
 * Cognito produksi, clock sistem, lockout store in-memory, dan verifier JWKS
 * default. Pengujian (task 7.3) menyuntikkan dependensi tiruan.
 */
export function createAuthService(deps: AuthServiceDeps = {}): AuthService {
  const config = deps.config ?? readCognitoConfig();
  const client = deps.client ?? getCognitoClient();
  const clock = deps.clock ?? systemClock;
  const lockoutStore = deps.lockoutStore ?? new InMemoryLockoutStore();
  const verifier = deps.verifier ?? getDefaultVerifier(config);

  /**
   * Memeriksa apakah email sedang terkunci. Mengembalikan sisa menit (dibulatkan
   * ke atas, minimum 1) bila terkunci; `null` bila tidak.
   */
  function getActiveLockMinutes(email: string): number | null {
    const record = lockoutStore.get(lockoutKey(email));
    if (!record || record.lockedUntil === null) {
      return null;
    }
    const remainingMs = record.lockedUntil - clock.now();
    if (remainingMs <= 0) {
      // Kunci kedaluwarsa: bersihkan agar penghitung mulai dari nol.
      lockoutStore.delete(lockoutKey(email));
      return null;
    }
    return Math.max(1, Math.ceil(remainingMs / (60 * 1000)));
  }

  /**
   * Mencatat satu kegagalan login. Saat mencapai `MAX_FAILED_ATTEMPTS`, menyetel
   * `lockedUntil` ke `now + LOCKOUT_DURATION_MS` (R1.5).
   */
  function recordFailure(email: string): void {
    const key = lockoutKey(email);
    const existing = lockoutStore.get(key) ?? { failures: 0, lockedUntil: null };
    const failures = existing.failures + 1;
    const lockedUntil =
      failures >= MAX_FAILED_ATTEMPTS ? clock.now() + LOCKOUT_DURATION_MS : null;
    lockoutStore.set(key, { failures, lockedUntil });
  }

  /** Mereset penghitung kegagalan setelah keberhasilan. */
  function resetFailures(email: string): void {
    lockoutStore.delete(lockoutKey(email));
  }

  async function signIn(
    email: string,
    password: string,
  ): Promise<SignInResult> {
    // Lockout diperiksa SEBELUM memanggil Cognito (R1.5).
    const lockedMinutes = getActiveLockMinutes(email);
    if (lockedMinutes !== null) {
      return { status: 'account_locked', retryAfterMinutes: lockedMinutes };
    }

    const authParameters: Record<string, string> = {
      USERNAME: email,
      PASSWORD: password,
    };
    const secretHash = computeSecretHash(email, config);
    if (secretHash) {
      authParameters.SECRET_HASH = secretHash;
    }

    let output: AdminInitiateAuthCommandOutput;
    try {
      output = await client.send(
        new AdminInitiateAuthCommand({
          UserPoolId: config.userPoolId,
          ClientId: config.clientId,
          AuthFlow: 'ADMIN_USER_PASSWORD_AUTH',
          AuthParameters: authParameters,
        }),
      );
    } catch (error) {
      if (isInvalidCredentialsError(error)) {
        recordFailure(email);
        // Setelah mencatat kegagalan, email mungkin baru saja terkunci.
        const nowLocked = getActiveLockMinutes(email);
        if (nowLocked !== null) {
          return { status: 'account_locked', retryAfterMinutes: nowLocked };
        }
        return { status: 'invalid_credentials' };
      }
      // Error lain (konfigurasi/jaringan) bukan kredensial salah — lempar ulang.
      throw error;
    }

    // Keberhasilan verifikasi kredensial → reset penghitung lockout.
    resetFailures(email);

    // Challenge FORCE_CHANGE_PASSWORD pada login pertama (R1.8).
    if (output.ChallengeName === 'NEW_PASSWORD_REQUIRED') {
      const session = output.Session;
      if (!session) {
        // Tanpa session tak mungkin melanjutkan challenge → deny-by-default.
        return { status: 'invalid_credentials' };
      }
      return { status: 'force_change_password', session };
    }

    const jwt = extractIdToken(output);
    if (!jwt) {
      // Tanpa token, perlakukan sebagai kegagalan generik (tidak membocorkan detail).
      return { status: 'invalid_credentials' };
    }
    return { status: 'ok', jwt };
  }

  async function completeNewPassword(
    session: string,
    newPassword: string,
    email?: string,
  ): Promise<SignInResult> {
    // Validasi panjang 8–128 via skema bersama (R1.9) SEBELUM memanggil Cognito.
    const parsed = newPasswordSchema.safeParse({ password: newPassword });
    if (!parsed.success) {
      // Kata sandi baru tidak memenuhi syarat → tolak, tahan akses (R1.9).
      return { status: 'invalid_credentials' };
    }

    const challengeResponses: Record<string, string> = {
      NEW_PASSWORD: newPassword,
    };
    if (email) {
      challengeResponses.USERNAME = email;
      const secretHash = computeSecretHash(email, config);
      if (secretHash) {
        challengeResponses.SECRET_HASH = secretHash;
      }
    }

    let output: AdminRespondToAuthChallengeCommandOutput;
    try {
      output = await client.send(
        new AdminRespondToAuthChallengeCommand({
          UserPoolId: config.userPoolId,
          ClientId: config.clientId,
          ChallengeName: 'NEW_PASSWORD_REQUIRED',
          Session: session,
          ChallengeResponses: challengeResponses,
        }),
      );
    } catch (error) {
      // Sandi baru menyalahi kebijakan pool → pesan aturan sandi, bukan 500.
      if (isPasswordPolicyError(error)) {
        return { status: 'password_policy_unmet' };
      }
      if (isInvalidCredentialsError(error)) {
        return { status: 'invalid_credentials' };
      }
      throw error;
    }

    // Cognito dapat merantai challenge lanjutan; perlakukan sebagai belum selesai.
    if (output.ChallengeName) {
      return { status: 'invalid_credentials' };
    }

    const jwt = extractIdToken(output);
    if (!jwt) {
      return { status: 'invalid_credentials' };
    }
    return { status: 'ok', jwt };
  }

  async function verifyToken(jwt: string): Promise<SessionClaims> {
    // Verifikasi tanda tangan + klaim standar (iss, aud, exp, token_use) via JWKS.
    // JWT invalid/kedaluwarsa → `verify` melempar → deny-by-default (R1.10 ditangani
    // Session_Guard yang memanggil fungsi ini).
    const claims = await verifier.verify(jwt);

    const cognitoSub = readStringClaim(claims, 'sub');
    const email = readStringClaim(claims, 'email');
    const role = readRoleClaim(claims);
    const schoolId = readSchoolIdClaim(claims);

    if (!cognitoSub || !email || role === null) {
      throw new Error('Klaim token tidak lengkap atau tidak valid.');
    }

    // Peran teacher WAJIB memiliki schoolId (R1.3, invarian SessionClaims);
    // admin boleh null. Teacher tanpa schoolId = klaim invalid → tolak.
    if (role === 'teacher' && !schoolId) {
      throw new Error('Guru tanpa school_id pada token adalah klaim invalid.');
    }

    // Pada titik ini: admin → schoolId boleh null; teacher → schoolId non-null
    // (sudah dijamin oleh pemeriksaan di atas).
    return {
      cognitoSub,
      email,
      role,
      schoolId,
    };
  }

  return { signIn, completeNewPassword, verifyToken };
}

/* ──────────────────────────────────────────────────────────────────────────
 * Ekstraksi klaim token (peran & school_id SELALU dari token — Property 3)
 * ────────────────────────────────────────────────────────────────────────── */

/** Membaca klaim string; mengembalikan `null` bila absen/bukan string non-kosong. */
function readStringClaim(
  claims: Record<string, unknown>,
  name: string,
): string | null {
  const value = claims[name];
  if (typeof value === 'string' && value.trim().length > 0) {
    return value;
  }
  return null;
}

/**
 * Menentukan peran dari grup token `cognito:groups`. Peran tidak pernah diambil
 * dari input klien (R1.2, Property 3).
 *
 * Aturan:
 * - Jika grup memuat `admin` → `admin` (admin diprioritaskan; hak lebih luas).
 * - Selain itu jika memuat `teacher` → `teacher`.
 * - Jika tidak ada grup yang dikenali → `null` (klaim invalid, deny-by-default).
 */
function readRoleClaim(claims: Record<string, unknown>): Role | null {
  const groups = claims['cognito:groups'];
  const list: string[] = Array.isArray(groups)
    ? groups.filter((g): g is string => typeof g === 'string')
    : [];

  if (list.includes(COGNITO_GROUPS.admin)) {
    return 'admin';
  }
  if (list.includes(COGNITO_GROUPS.teacher)) {
    return 'teacher';
  }
  return null;
}

/**
 * Membaca `schoolId` dari klaim `custom:school_id`. `school_id` yang dikirim
 * klien diabaikan — hanya nilai klaim token yang dipakai (R1.3, Property 3).
 * Mengembalikan `null` bila absen (valid untuk admin; invalid untuk teacher,
 * ditolak di `verifyToken`).
 */
function readSchoolIdClaim(claims: Record<string, unknown>): string | null {
  return readStringClaim(claims, COGNITO_SCHOOL_ID_ATTRIBUTE);
}

/**
 * Instance Auth_Service default (produksi). Lazy agar konfigurasi environment
 * hanya dibaca saat benar-benar dipakai (menghindari kegagalan import saat env
 * belum tersetel, mis. pada sebagian tahap build/test).
 */
let defaultAuthService: AuthService | undefined;

/** Mengembalikan Auth_Service default (singleton, lazy). */
export function getAuthService(): AuthService {
  if (!defaultAuthService) {
    defaultAuthService = createAuthService();
  }
  return defaultAuthService;
}
